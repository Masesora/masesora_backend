from fastapi import APIRouter
from typing import List
from masesora_backend.database.database import db
from masesora_backend.models.symptom_master import SymptomMaster

router = APIRouter(prefix="/symptom-master", tags=["symptom-master"])

SYMPTOMS: List[dict] = [
    {
  "specialty": "finanzas",
  "symptoms": [
    {
      "id": "UCI-S1",
      "name": "Hemorragia de Caja",
      "specialty": "finanzas",
      "plan": "PIE",
      "domain": "liquidez",
      "description": "Pérdida inmediata y peligrosa de liquidez que compromete la estabilidad operativa.",
      "kpi": {
        "question": "¿Cuánto tiempo aguantas vivo si hoy dejas de vender?",
        "scale_min": 1,
        "scale_max": 4
      },
      "thresholds": {
        "critical": 70,
        "recommended": 85,
        "optimizer": 95,
        "elite": 100
      },
      "treatment": {
        "decision": "Priorización de pagos",
        "decision_explanation": "Detener la pérdida inmediata de liquidez",
        "action": "Arqueo y plan de cobro inmediato",
        "action_explanation": "Evita colapso financiero inmediato",
        "tool": "Matriz de Tesorería",
        "tool_explanation": "Detecta dónde se pierde dinero",
        "objective": "Aumentar liquidez inmediata y evitar ruptura de caja",
        "kpi_target": "Días de vida > 30",
        "activation_condition": "Liquidez < 15 días",
        "success_condition": "Liquidez estabilizada por encima de 30 días",
        "risk_if_ignored": "Riesgo de quiebra operativa en menos de 30 días",
        "sequence": [
          "Realizar arqueo inmediato",
          "Clasificar pagos urgentes",
          "Ejecutar plan de cobro acelerado"
        ],
        "impact_level": "alto",
        "timeframe": "48-72 horas"
      },
      "master_treatment": {
        "master_decision": "Gobierno de Liquidez",
        "master_decision_explanation": "Controlar flujo vital del negocio",
        "master_action": "Diseñar sistema de control de caja",
        "master_action_explanation": "Evita recaídas y estabiliza finanzas",
        "master_tool": "Radar de Liquidez",
        "master_tool_explanation": "Monitorea salud financiera en tiempo real"
      },
      "inputs": {
        "input_a": "Saldo Total promedio últimos 3 meses",
        "input_b": "Gastos Fijos: Nóminas, alquiler y cuotas",
        "formula": "Saldo / (Gastos / 30)",
        "impact": "Días de Vida: Tiempo de reacción antes de quebrar"
      },
      "review": {
        "input_revised_1": "Saldo Post",
        "input_revised_2": "Pagos Post",
        "result_revised": "+ Días vida"
      }
    },
    {
      "id": "UCI-S2",
      "name": "Infección de Margen",
      "specialty": "finanzas",
      "plan": "PIE",
      "domain": "rentabilidad",
      "description": "Margen insuficiente que compromete la sostenibilidad del negocio.",
      "kpi": {
        "question": "¿Cada euro que entra te hace más rico o más pobre?",
        "scale_min": 1,
        "scale_max": 4
      },
      "thresholds": {
        "critical": 70,
        "recommended": 85,
        "optimizer": 95,
        "elite": 100
      },
      "treatment": {
        "decision": "Saneamiento de cartera",
        "decision_explanation": "Eliminar productos o clientes que destruyen margen",
        "action": "Escandallo de costes vs. precios",
        "action_explanation": "Detecta fugas de rentabilidad",
        "tool": "Análisis Pareto 80/20",
        "tool_explanation": "Identifica los productos que sostienen el negocio",
        "objective": "Aumentar margen bruto por encima del 40%",
        "kpi_target": "Margen > 40%",
        "activation_condition": "Margen < 25%",
        "success_condition": "Margen estabilizado por encima del 40%",
        "risk_if_ignored": "Pérdida progresiva de rentabilidad",
        "sequence": [
          "Analizar productos por margen",
          "Eliminar productos vampiro",
          "Reajustar precios"
        ],
        "impact_level": "alto",
        "timeframe": "1-2 semanas"
      },
      "master_treatment": {
        "master_decision": "Gobierno de Rentabilidad",
        "master_decision_explanation": "Asegurar que cada venta suma y no resta",
        "master_action": "Reestructurar portafolio",
        "master_action_explanation": "Eliminar productos vampiro",
        "master_tool": "Radar de Margen",
        "master_tool_explanation": "Monitoriza la salud del margen en tiempo real"
      },
      "inputs": {
        "input_a": "Ventas del Mes",
        "input_b": "Compras del Mes",
        "formula": "((Ventas - Compras) / Ventas) x 100",
        "impact": "% Margen: Cuántos céntimos te quedan de cada euro"
      },
      "review": {
        "input_revised_1": "Ingresos Post",
        "input_revised_2": "Costes Post",
        "result_revised": "+ % Margen"
      }
    },
    {
      "id": "UCI-S3",
      "name": "Isquemia de Facturación",
      "specialty": "finanzas",
      "plan": "PIE",
      "domain": "cobros",
      "description": "Brecha entre lo facturado y lo realmente cobrado.",
      "kpi": {
        "question": "¿El dinero que facturas realmente llega al banco?",
        "scale_min": 1,
        "scale_max": 4
      },
      "thresholds": {
        "critical": 70,
        "recommended": 85,
        "optimizer": 95,
        "elite": 100
      },
      "treatment": {
        "decision": "Aceleración de ciclo",
        "decision_explanation": "Reducir el tiempo entre venta y cobro",
        "action": "Facturar hitos y adelantar cobros",
        "action_explanation": "Aumenta liquidez inmediata",
        "tool": "Ciclo de Caja",
        "tool_explanation": "Visualiza dónde se atasca el dinero",
        "objective": "Reducir brecha de cobro a menos del 10%",
        "kpi_target": "Brecha < 10%",
        "activation_condition": "Brecha > 20%",
        "success_condition": "Brecha reducida por debajo del 10%",
        "risk_if_ignored": "Tensiones de caja recurrentes",
        "sequence": [
          "Revisar facturación pendiente",
          "Contactar clientes con deuda",
          "Reestructurar hitos de cobro"
        ],
        "impact_level": "alto",
        "timeframe": "72 horas"
      },
      "master_treatment": {
        "master_decision": "Gobierno de Cobros",
        "master_decision_explanation": "Eliminar la brecha entre facturación y liquidez real",
        "master_action": "Reestructurar política de cobros",
        "master_action_explanation": "Evita tensiones de caja",
        "master_tool": "Radar de Cobros",
        "master_tool_explanation": "Monitoriza cobros en tiempo real"
      },
      "inputs": {
        "input_a": "Total Facturado",
        "input_b": "Total Cobrado",
        "formula": "Facturado - Cobrado",
        "impact": "Brecha de Cobro: Dinero que falta para tener éxito real"
      },
      "review": {
        "input_revised_1": "Ventas Post",
        "input_revised_2": "Cobros Post",
        "result_revised": "€ Rescatados"
      }
    },
    {
      "id": "UCI-S4",
      "name": "Arritmia de Cobro",
      "specialty": "finanzas",
      "plan": "PRE",
      "domain": "cobros",
      "description": "Clientes que pagan tarde o cuando quieren.",
      "kpi": {
        "question": "¿Tus clientes te pagan cuando deben o cuando quieren?",
        "scale_min": 1,
        "scale_max": 4
      },
      "thresholds": {
        "critical": 70,
        "recommended": 85,
        "optimizer": 95,
        "elite": 100
      },
      "treatment": {
        "decision": "Filtro de calidad",
        "decision_explanation": "Clasificar clientes por riesgo",
        "action": "Clasificación de clientes por riesgo y valor",
        "action_explanation": "Evita impagos futuros",
        "tool": "Regla 5/25",
        "tool_explanation": "Detecta clientes tóxicos",
        "objective": "Reducir días de cobro",
        "kpi_target": "Días de cobro < 45",
        "activation_condition": "Días de cobro > 60",
        "success_condition": "Cobro estabilizado por debajo de 45 días",
        "risk_if_ignored": "Aumento de impagos",
        "sequence": [
          "Clasificar clientes por riesgo",
          "Reestructurar condiciones de pago",
          "Aplicar recordatorios automáticos"
        ],
        "impact_level": "medio",
        "timeframe": "1 semana"
      },
      "master_treatment": {
        "master_decision": "Gobierno de Cartera",
        "master_decision_explanation": "Asegurar recurrencia y salud financiera",
        "master_action": "Reestructurar cartera",
        "master_action_explanation": "Eliminar clientes de alto riesgo",
        "master_tool": "Radar de Cartera",
        "master_tool_explanation": "Monitoriza riesgo de clientes"
      },
      "inputs": {
        "input_a": "Deuda Clientes",
        "input_b": "Venta Diaria",
        "formula": "Deuda / Venta Diaria",
        "impact": "Días de Espera: Cuánto tardas de media en cobrar"
      },
      "review": {
        "input_revised_1": "Saldo Nuevo",
        "input_revised_2": "Venta Mes",
        "result_revised": "- Días cobro"
      }
    },
    {
      "id": "UCI-S5",
      "name": "Atrofia de Stock",
      "specialty": "finanzas",
      "plan": "PRE",
      "domain": "inventario",
      "description": "Stock inmovilizado que destruye liquidez.",
      "kpi": {
        "question": "¿Cuánto dinero tienes parado en estanterías?",
        "scale_min": 1,
        "scale_max": 4
      },
      "thresholds": {
        "critical": 70,
        "recommended": 85,
        "optimizer": 95,
        "elite": 100
      },
      "treatment": {
        "decision": "Liquidación de activos",
        "decision_explanation": "Recuperar liquidez inmediata",
        "action": "Auditoría física de inventario inmovilizado",
        "action_explanation": "Detecta stock muerto",
        "tool": "Matriz ABC de Stock",
        "tool_explanation": "Clasifica inventario por rotación",
        "objective": "Reducir meses de stock",
        "kpi_target": "Meses de stock < 2",
        "activation_condition": "Meses de stock > 4",
        "success_condition": "Stock estabilizado por debajo de 2 meses",
        "risk_if_ignored": "Pérdida de liquidez",
        "sequence": [
          "Auditar inventario",
          "Clasificar por rotación",
          "Liquidar stock muerto"
        ],
        "impact_level": "medio",
        "timeframe": "1-2 semanas"
      },
      "master_treatment": {
        "master_decision": "Gobierno de Inventario",
        "master_decision_explanation": "Evitar acumulación de stock improductivo",
        "master_action": "Optimizar rotación",
        "master_action_explanation": "Aumenta liquidez",
        "master_tool": "Radar de Stock",
        "master_tool_explanation": "Monitoriza rotación real"
      },
      "inputs": {
        "input_a": "Valor Almacén",
        "input_b": "Salida Almacén",
        "formula": "Almacén / Salida Mes",
        "impact": "Meses de Stock: Tiempo que podrías vender sin comprar nada"
      },
      "review": {
        "input_revised_1": "Valor Nuevo",
        "input_revised_2": "Coste Venta",
        "result_revised": "€ Liquidez"
      }
    },
    {
      "id": "UCI-S6",
      "name": "Tensión con Proveedores",
      "specialty": "finanzas",
      "plan": "PRE",
      "domain": "proveedores",
      "description": "Dependencia excesiva de plazos de pago.",
      "kpi": {
        "question": "¿Tus proveedores te financian o te ahogan?",
        "scale_min": 1,
        "scale_max": 4
      },
      "thresholds": {
        "critical": 70,
        "recommended": 85,
        "optimizer": 95,
        "elite": 100
      },
      "treatment": {
        "decision": "Apalancamiento operativo",
        "decision_explanation": "Ganar días de pago",
        "action": "Renegociar plazos y centralizar compras",
        "action_explanation": "Aumenta margen de maniobra",
        "tool": "Cuadro Negociación DPO",
        "tool_explanation": "Optimiza días de pago",
        "objective": "Aumentar días de pago",
        "kpi_target": "DPO > 45",
        "activation_condition": "DPO < 30",
        "success_condition": "DPO estabilizado por encima de 45",
        "risk_if_ignored": "Tensión de caja crónica",
        "sequence": [
          "Revisar deuda con proveedores",
          "Renegociar plazos",
          "Centralizar compras"
        ],
        "impact_level": "medio",
        "timeframe": "1 semana"
      },
      "master_treatment": {
        "master_decision": "Gobierno de Proveedores",
        "master_decision_explanation": "Controlar dependencia financiera",
        "master_action": "Optimizar compras",
        "master_action_explanation": "Evita tensiones de caja",
        "master_tool": "Radar de Proveedores",
        "master_tool_explanation": "Monitoriza DPO real"
      },
      "inputs": {
        "input_a": "Deuda Proveedores",
        "input_b": "Compra Diaria",
        "formula": "Deuda / Compra Diaria",
        "impact": "Días de Aire: Cuánto tiempo te están financiando"
      },
      "review": {
        "input_revised_1": "Saldo Nuevo",
        "input_revised_2": "Compras Mes",
        "result_revised": "+ Días pago"
      }
    },
    {
      "id": "UCI-S7",
      "name": "Colapso de Deuda",
      "specialty": "finanzas",
      "plan": "PRE",
      "domain": "endeudamiento",
      "description": "La deuda supera la capacidad de pago real.",
      "kpi": {
        "question": "¿Eres dueño de tu empresa o trabajas para el banco?",
        "scale_min": 1,
        "scale_max": 4
      },
      "thresholds": {
        "critical": 70,
        "recommended": 85,
        "optimizer": 95,
        "elite": 100
      },
      "treatment": {
        "decision": "Reestructuración de pasivo",
        "decision_explanation": "Reducir carga financiera",
        "action": "Actualización de Pool y Scoring Bancario",
        "action_explanation": "Mejora condiciones de deuda",
        "tool": "Dossier Bancario",
        "tool_explanation": "Negocia mejor con bancos",
        "objective": "Aumentar ratio de libertad financiera",
        "kpi_target": "Ratio > 2",
        "activation_condition": "Ratio < 1",
        "success_condition": "Ratio estabilizado por encima de 2",
        "risk_if_ignored": "Dependencia bancaria peligrosa",
        "sequence": [
          "Actualizar scoring",
          "Reestructurar préstamos",
          "Negociar nuevas condiciones"
        ],
        "impact_level": "alto",
        "timeframe": "2-4 semanas"
      },
      "master_treatment": {
        "master_decision": "Gobierno de Deuda",
        "master_decision_explanation": "Evitar dependencia bancaria",
        "master_action": "Optimizar estructura financiera",
        "master_action_explanation": "Aumenta solvencia",
        "master_tool": "Radar de Deuda",
        "master_tool_explanation": "Monitoriza ratios clave"
      },
      "inputs": {
        "input_a": "Beneficio Mes",
        "input_b": "Cuota Banco",
        "formula": "Beneficio / Cuota",
        "impact": "Ratio Libertad: Cuántas veces pagas la cuota con tu beneficio"
      },
      "review": {
        "input_revised_1": "Nuevo Ben.",
        "input_revised_2": "Nueva Cuota",
        "result_revised": "Solvencia Mejorada"
      }
    },
    {
      "id": "UCI-S8",
      "name": "Canibalismo de Oferta",
      "specialty": "finanzas",
      "plan": "PRE",
      "domain": "portafolio",
      "description": "Productos que consumen más recursos de los que generan.",
      "kpi": {
        "question": "¿Tus productos estrella realmente sostienen tu negocio?",
        "scale_min": 1,
        "scale_max": 4
      },
      "thresholds": {
        "critical": 70,
        "recommended": 85,
        "optimizer": 95,
        "elite": 100
      },
      "treatment": {
        "decision": "Purga de portafolio",
        "decision_explanation": "Eliminar productos con margen insuficiente",
        "action": "Escandallo de costes vs. precios",
        "action_explanation": "Detecta productos vampiro",
        "tool": "Matriz Margen/Esfuerzo",
        "tool_explanation": "Evalúa rentabilidad real",
        "objective": "Aumentar ROI de la oferta",
        "kpi_target": "ROI > 20%",
        "activation_condition": "ROI < 10%",
        "success_condition": "Portafolio con > 70% productos rentables",
        "risk_if_ignored": "Pérdida de margen y desgaste operativo",
        "sequence": [
          "Analizar productos por margen",
          "Eliminar productos vampiro",
          "Reforzar productos estrella"
        ],
        "impact_level": "alto",
        "timeframe": "2 semanas"
      },
      "master_treatment": {
        "master_decision": "Gobierno de Oferta",
        "master_decision_explanation": "Optimizar catálogo para maximizar rentabilidad",
        "master_action": "Eliminar productos tóxicos",
        "master_action_explanation": "Aumenta margen global",
        "master_tool": "Radar de Oferta",
        "master_tool_explanation": "Monitoriza ROI real"
      },
      "inputs": {
        "input_a": "Beneficio Producto",
        "input_b": "Horas/Coste Inv.",
        "formula": "Beneficio / Inversión",
        "impact": "ROI de Oferta: Rentabilidad real de lo que vendes"
      },
      "review": {
        "input_revised_1": "Nuevo Ben.",
        "input_revised_2": "Nuevo Coste",
        "result_revised": "+ Rentabilidad"
      }
    },
    {
      "id": "UCI-S9",
      "name": "Obesidad de Gasto Fijo",
      "specialty": "finanzas",
      "plan": "PRE",
      "domain": "estructura",
      "description": "Gastos fijos descontrolados que reducen margen.",
      "kpi": {
        "question": "¿Sabes cuánto vas a gastar este mes?",
        "scale_min": 1,
        "scale_max": 4
      },
      "thresholds": {
        "critical": 70,
        "recommended": 85,
        "optimizer": 95,
        "elite": 100
      },
      "treatment": {
        "decision": "Ablación de estructura",
        "decision_explanation": "Eliminar gastos sin retorno",
        "action": "Cortar gastos que no generan ROI",
        "action_explanation": "Aumenta margen neto",
        "tool": "Presupuesto Cero",
        "tool_explanation": "Evalúa cada gasto desde cero",
        "objective": "Reducir desviación presupuestaria",
        "kpi_target": "Desviación < 10%",
        "activation_condition": "Desviación > 25%",
        "success_condition": "Gasto fijo estabilizado",
        "risk_if_ignored": "Pérdida de margen y tensiones de caja",
        "sequence": [
          "Comparar gasto real vs. presupuestado",
          "Eliminar gastos sin ROI",
          "Reasignar presupuesto"
        ],
        "impact_level": "medio",
        "timeframe": "1 mes"
      },
      "master_treatment": {
        "master_decision": "Gobierno de Estructura",
        "master_decision_explanation": "Controlar gastos fijos estratégicamente",
        "master_action": "Optimizar estructura de costes",
        "master_action_explanation": "Aumenta rentabilidad sostenible",
        "master_tool": "Radar de Costes",
        "master_tool_explanation": "Monitoriza desviaciones"
      },
      "inputs": {
        "input_a": "Presupuesto",
        "input_b": "Gasto Real",
        "formula": "((Real - Presu) / Presu) x 100",
        "impact": "% Desviación: Nivel de control sobre el timón de la empresa"
      },
      "review": {
        "input_revised_1": "Gasto Presup.",
        "input_revised_2": "Gasto Real",
        "result_revised": "- Desviación"
      }
    },
    {
      "id": "UCI-S10",
      "name": "Caja Blindada",
      "specialty": "finanzas",
      "plan": "PRE",
      "domain": "excelencia",
      "description": "Nivel 10: Excelencia financiera. Reserva estratégica que garantiza estabilidad.",
      "kpi": {
        "question": "¿Cuántos meses puedes sobrevivir sin ingresos?",
        "scale_min": 1,
        "scale_max": 4
      },
      "thresholds": {
        "critical": 70,
        "recommended": 85,
        "optimizer": 95,
        "elite": 100
      },
      "treatment": {
        "decision": "Asegurar reserva estratégica",
        "decision_explanation": "Crear colchón financiero real",
        "action": "Escandallo de Oro S10",
        "action_explanation": "Define el nivel de reserva ideal",
        "tool": "Radar de Liquidez S10",
        "tool_explanation": "Monitoriza reserva estratégica",
        "objective": "Alcanzar reserva de seguridad equivalente a 3 meses",
        "kpi_target": "Reserva ≥ 3 meses",
        "activation_condition": "Reserva < 2 meses",
        "success_condition": "Reserva estabilizada en ≥ 3 meses",
        "risk_if_ignored": "Vulnerabilidad ante crisis o caídas de ventas",
        "sequence": [
          "Calcular gasto estructura",
          "Definir fondo de reserva",
          "Constituir reserva mensual"
        ],
        "impact_level": "alto",
        "timeframe": "3-6 meses"
      },
      "master_treatment": {
        "master_decision": "Gobierno de Liquidez S10",
        "master_decision_explanation": "Blindar la estabilidad financiera",
        "master_action": "Consolidar fondo de reserva",
        "master_action_explanation": "Garantiza paz mental del dueño",
        "master_tool": "Radar S10",
        "master_tool_explanation": "Monitoriza reserva estratégica"
      },
      "inputs": {
        "input_a": "Fondo Reserva",
        "input_b": "Gasto Estructura",
        "formula": "Fondo / Gasto Estructura",
        "impact": "Sello S10: Meses de tranquilidad absoluta"
      },
      "review": {
        "input_revised_1": "Reserva Final",
        "input_revised_2": "Gasto Estruc.",
        "result_revised": "S10 Sello"
  }
}
  ]
},
{ 
  "specialty": "procesos",
  "symptoms": [
    {
    "id": "UNI-S1",
    "name": "Esclerosis de Esperas",
    "specialty": "procesos",
    "plan": "PIE",
    "domain": "tiempos",
    "description": "Tiempos muertos entre pasos que ralentizan la entrega al cliente.",

    "kpi": {
      "question": "¿Cuántos días tardas en cumplir tu promesa al cliente?",
      "scale_min": 1,
      "scale_max": 4
    },

    "thresholds": {
      "critical": 70,
      "recommended": 85,
      "optimizer": 95,
      "elite": 100
    },

    "treatment": {
      "decision": "Mapeo de tiempos muertos",
      "decision_explanation": "Detectar dónde se pierde tiempo",
      "action": "Cronometrar pasos entre puestos",
      "action_explanation": "Permite eliminar esperas innecesarias",
      "tool": "Diagrama de Valor",
      "tool_explanation": "Visualiza cuellos de botella",

      "objective": "Reducir el lead time total del proceso",
      "kpi_target": "Lead time < 5 días",
      "activation_condition": "Lead time > 10 días",
      "success_condition": "Lead time estabilizado por debajo de 5 días",
      "risk_if_ignored": "Pérdida de clientes por lentitud",
      "sequence": [
        "Medir tiempos entre pasos",
        "Identificar esperas críticas",
        "Eliminar pasos sin valor"
      ],
      "impact_level": "alto",
      "timeframe": "1 semana"
    },

    "master_treatment": {
      "master_decision": "Gobierno de Flujo",
      "master_decision_explanation": "Asegurar velocidad operativa",
      "master_action": "Optimizar secuencia de procesos",
      "master_action_explanation": "Reduce tiempos de entrega",
      "master_tool": "Radar de Flujo",
      "master_tool_explanation": "Monitoriza lead time real"
    },

    "inputs": {
      "input_a": "Día de Pedido",
      "input_b": "Día de Entrega",
      "formula": "Día Entrega - Día Pedido",
      "impact": "Lead Time: Días que tardas en cumplir tu promesa"
    },

    "review": {
      "input_revised_1": "Pedido Revisado",
      "input_revised_2": "Entrega Revisada",
      "result_revised": "Lead Time Optimizado"
    }
  },
  {
    "id": "UNI-S2",
    "name": "Colapso de Agendas",
    "specialty": "procesos",
    "plan": "PIE",
    "domain": "productividad",
    "description": "Tareas ruido y cuellos de botella que saturan la agenda.",

    "kpi": {
      "question": "¿Cuánto dinero quema el error y la repetición?",
      "scale_min": 1,
      "scale_max": 4
    },

    "thresholds": {
      "critical": 70,
      "recommended": 85,
      "optimizer": 95,
      "elite": 100
    },

    "treatment": {
      "decision": "Priorización de valor",
      "decision_explanation": "Eliminar tareas que no aportan",
      "action": "Auditoría de tiempos de gerencia",
      "action_explanation": "Detecta saturación real",
      "tool": "Regla 5/25 de Tareas",
      "tool_explanation": "Identifica tareas críticas",

      "objective": "Reducir tareas ruido y liberar agenda",
      "kpi_target": "Desperdicio < 10%",
      "activation_condition": "Desperdicio > 25%",
      "success_condition": "Agenda con > 60% tareas de valor",
      "risk_if_ignored": "Colapso operativo y retrasos",
      "sequence": [
        "Auditar tareas",
        "Eliminar tareas ruido",
        "Reorganizar agenda"
      ],
      "impact_level": "alto",
      "timeframe": "1 semana"
    },

    "master_treatment": {
      "master_decision": "Gobierno de Agenda",
      "master_decision_explanation": "Liberar tiempo de alto valor",
      "master_action": "Rediseñar agenda operativa",
      "master_action_explanation": "Aumenta productividad real",
      "master_tool": "Radar de Agenda",
      "master_tool_explanation": "Monitoriza carga de trabajo"
    },

    "inputs": {
      "input_a": "Nº Errores",
      "input_b": "Coste Medio",
      "formula": "Nº Errores x Coste Medio",
      "impact": "Tasa de Desperdicio: Dinero tirado por falta de proceso"
    },

    "review": {
      "input_revised_1": "Errores Post",
      "input_revised_2": "Coste Post",
      "result_revised": "Desperdicio Reducido"
    }
  },
  {
    "id": "UNI-S3",
    "name": "Fugas de Calidad",
    "specialty": "procesos",
    "plan": "PIE",
    "domain": "calidad",
    "description": "Errores recurrentes por falta de estandarización.",

    "kpi": {
      "question": "¿Tu equipo está saturado o infrautilizado?",
      "scale_min": 1,
      "scale_max": 4
    },

    "thresholds": {
      "critical": 70,
      "recommended": 85,
      "optimizer": 95,
      "elite": 100
    },

    "treatment": {
      "decision": "Estandarización crítica",
      "decision_explanation": "Eliminar errores repetitivos",
      "action": "Redactar protocolos de fallos recurrentes",
      "action_explanation": "Reduce variabilidad",
      "tool": "Checklist de Calidad",
      "tool_explanation": "Evita errores por falta de información",

      "objective": "Reducir errores operativos",
      "kpi_target": "Errores < 5%",
      "activation_condition": "Errores > 15%",
      "success_condition": "Errores estabilizados por debajo del 5%",
      "risk_if_ignored": "Pérdida de clientes por mala calidad",
      "sequence": [
        "Identificar fallos recurrentes",
        "Crear protocolos",
        "Aplicar checklist"
      ],
      "impact_level": "alto",
      "timeframe": "2 semanas"
    },

    "master_treatment": {
      "master_decision": "Gobierno de Calidad",
      "master_decision_explanation": "Asegurar consistencia operativa",
      "master_action": "Crear manual base",
      "master_action_explanation": "Evita fallos estructurales",
      "master_tool": "Radar de Calidad",
      "master_tool_explanation": "Monitoriza saturación real"
    },

    "inputs": {
      "input_a": "Horas Equipo",
      "input_b": "Horas Tarea",
      "formula": "(Horas Tarea / Horas Equipo) x 100",
      "impact": "% Saturación: Riesgo de infarto en la operativa"
    },

    "review": {
      "input_revised_1": "Horas Equipo Post",
      "input_revised_2": "Horas Tarea Post",
      "result_revised": "Saturación Reducida"
    }
  },
  {
    "id": "UNI-S4",
    "name": "Micro-Fugas de Tiempo",
    "specialty": "procesos",
    "plan": "PRE",
    "domain": "eficiencia",
    "description": "Pasos innecesarios que no aportan valor al cliente.",

    "kpi": {
      "question": "¿Cuántos pasos de tu proceso no aportan valor?",
      "scale_min": 1,
      "scale_max": 4
    },

    "thresholds": {
      "critical": 70,
      "recommended": 85,
      "optimizer": 95,
      "elite": 100
    },

    "treatment": {
      "decision": "Eliminación de desperdicio",
      "decision_explanation": "Eliminar pasos inútiles",
      "action": "Auditoría de desperdicios LEAN",
      "action_explanation": "Detecta grasa operativa",
      "tool": "Hoja de Desperdicios",
      "tool_explanation": "Clasifica pasos por valor",

      "objective": "Eliminar pasos sin valor",
      "kpi_target": "Grasa operativa < 10%",
      "activation_condition": "Grasa > 25%",
      "success_condition": "Proceso con > 70% pasos de valor",
      "risk_if_ignored": "Procesos lentos y costosos",
      "sequence": [
        "Mapear proceso",
        "Clasificar pasos",
        "Eliminar pasos sin valor"
      ],
      "impact_level": "medio",
      "timeframe": "1 semana"
    },

    "master_treatment": {
      "master_decision": "Gobierno de Flujo",
      "master_decision_explanation": "Asegurar eficiencia máxima",
      "master_action": "Balanceo de cargas",
      "master_action_explanation": "Reduce tiempos muertos",
      "master_tool": "Radar de Valor",
      "master_tool_explanation": "Monitoriza pasos críticos"
    },

    "inputs": {
      "input_a": "Nº Pasos Totales",
      "input_b": "Nº Pasos Valor",
      "formula": "Pasos Totales - Pasos Valor",
      "impact": "Grasa Operativa: Pasos sobrantes que hay que extirpar"
    },

    "review": {
      "input_revised_1": "Pasos Totales Post",
      "input_revised_2": "Pasos Valor Post",
      "result_revised": "Grasa Reducida"
    }
  },
  {
    "id": "UNI-S5",
    "name": "Obsolescencia de Método",
    "specialty": "procesos",
    "plan": "PRE",
    "domain": "mejora continua",
    "description": "Métodos antiguos que generan errores y baja calidad.",

    "kpi": {
      "question": "¿Qué tan sana está tu producción?",
      "scale_min": 1,
      "scale_max": 4
    },

    "thresholds": {
      "critical": 70,
      "recommended": 85,
      "optimizer": 95,
      "elite": 100
    },

    "treatment": {
      "decision": "Actualización de técnica",
      "decision_explanation": "Eliminar métodos obsoletos",
      "action": "Implementar una mejora semanal",
      "action_explanation": "Aumenta calidad real",
      "tool": "Círculo de Mejora Continua",
      "tool_explanation": "Sistema de mejora constante",

      "objective": "Aumentar calidad operativa",
      "kpi_target": "Índice de salud > 90%",
      "activation_condition": "Índice < 75%",
      "success_condition": "Índice estabilizado por encima del 90%",
      "risk_if_ignored": "Errores recurrentes y pérdida de clientes",
      "sequence": [
        "Identificar fallos",
        "Aplicar mejora semanal",
        "Revisar impacto"
      ],
      "impact_level": "medio",
      "timeframe": "4 semanas"
    },

    "master_treatment": {
      "master_decision": "Gobierno de Método",
      "master_decision_explanation": "Asegurar calidad sostenible",
      "master_action": "Actualizar procesos clave",
      "master_action_explanation": "Evita errores repetitivos",
      "master_tool": "Radar de Método",
      "master_tool_explanation": "Monitoriza salud operativa"
    },

    "inputs": {
      "input_a": "Total Pedidos",
      "input_b": "Quejas",
      "formula": "((Total - Quejas) / Total) x 100",
      "impact": "Índice de Salud: Calidad real de tu producción"
    },

    "review": {
      "input_revised_1": "Pedidos Post",
      "input_revised_2": "Quejas Post",
      "result_revised": "Salud Mejorada"
    }
  },
  {
    "id": "UNI-S6",
    "name": "Despilfarro",
    "specialty": "procesos",
    "plan": "PRE",
    "domain": "desperdicio",
    "description": "Desperdicios por movimientos, esperas o stock innecesario.",

    "kpi": {
      "question": "¿Cuánta dependencia tienes de la memoria individual?",
      "scale_min": 1,
      "scale_max": 4
    },

    "thresholds": {
      "critical": 70,
      "recommended": 85,
      "optimizer": 95,
      "elite": 100
    },

    "treatment": {
      "decision": "Eliminación de grasa",
      "decision_explanation": "Reducir desperdicios",
      "action": "Localizar desperdicios en el flujo",
      "action_explanation": "Evita pérdidas ocultas",
      "tool": "Sistema Kan-Ban",
      "tool_explanation": "Optimiza reposición",

      "objective": "Reducir desperdicios operativos",
      "kpi_target": "Autonomía > 80%",
      "activation_condition": "Autonomía < 60%",
      "success_condition": "Autonomía estabilizada por encima del 80%",
      "risk_if_ignored": "Dependencia de personas clave",
      "sequence": [
        "Identificar desperdicios",
        "Aplicar Kan-Ban",
        "Estandarizar reposición"
      ],
      "impact_level": "medio",
      "timeframe": "2 semanas"
    },

    "master_treatment": {
      "master_decision": "Gobierno de Desperdicio",
      "master_decision_explanation": "Eliminar pérdidas estructurales",
      "master_action": "Estandarizar reposición",
      "master_action_explanation": "Evita roturas de stock",
      "master_tool": "Radar de Mudas",
      "master_tool_explanation": "Monitoriza desperdicios"
    },

    "inputs": {
      "input_a": "Tareas Críticas",
      "input_b": "Tareas Escritas",
      "formula": "Tareas Escritas / Tareas Críticas",
      "impact": "Ratio Autonomía: Seguridad si falta una persona clave"
    },

    "review": {
      "input_revised_1": "Críticas Post",
      "input_revised_2": "Escritas Post",
      "result_revised": "Autonomía Mejorada"
    }
  },
  {
    "id": "UNI-S7",
    "name": "Dependencia",
    "specialty": "procesos",
    "plan": "PRE",
    "domain": "roles",
    "description": "Dependencia excesiva de personas clave.",

    "kpi": {
      "question": "¿Cuántas horas podrías recuperar con tecnología adecuada?",
      "scale_min": 1,
      "scale_max": 4
    },

    "thresholds": {
      "critical": 70,
      "recommended": 85,
      "optimizer": 95,
      "elite": 100
    },

    "treatment": {
      "decision": "Protocolización de roles",
      "decision_explanation": "Independizar cargos",
      "action": "Crear fichas de puesto con KPIs claros",
      "action_explanation": "Reduce dependencia",
      "tool": "Matriz de Polivalencia",
      "tool_explanation": "Evalúa cobertura de roles",

      "objective": "Reducir dependencia de personas clave",
      "kpi_target": "Horas recuperables > 20%",
      "activation_condition": "Dependencia > 40%",
      "success_condition": "Dependencia reducida por debajo del 20%",
      "risk_if_ignored": "Parálisis operativa si falta una persona",
      "sequence": [
        "Identificar roles críticos",
        "Crear fichas de puesto",
        "Redistribuir cargas"
      ],
      "impact_level": "alto",
      "timeframe": "3 semanas"
    },

    "master_treatment": {
      "master_decision": "Gobierno de Roles",
      "master_decision_explanation": "Asegurar continuidad operativa",
      "master_action": "Redistribuir cargas",
      "master_action_explanation": "Evita cuellos de botella humanos",
      "master_tool": "Radar de Roles",
      "master_tool_explanation": "Monitoriza dependencia real"
    },

    "inputs": {
      "input_a": "Tiempo a Mano",
      "input_b": "Tiempo Auto",
      "formula": "Tiempo Mano - Tiempo Auto",
      "impact": "Potencial Mejora: Horas de vida recuperables al mes"
    },

    "review": {
      "input_revised_1": "Mano Post",
      "input_revised_2": "Auto Post",
      "result_revised": "Horas Recuperadas"
    }
  },
  {
  "id": "UNI-S8",
  "name": "Comunicación Interna Deficiente",
  "specialty": "procesos",
  "plan": "PRE",
  "domain": "comunicación",
  "description": "Órdenes dispersas y falta de canal oficial.",

  "kpi": {
    "question": "¿Decides por datos o por olfato?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Ritmos de gestión",
    "decision_explanation": "Centralizar órdenes",
    "action": "Implementar stand-up meeting diario",
    "action_explanation": "Aumenta claridad",
    "tool": "Manual de Comunicación Interna",
    "tool_explanation": "Define canales oficiales",

    "objective": "Aumentar claridad operativa",
    "kpi_target": "Nivel de control > 80%",
    "activation_condition": "Control < 60%",
    "success_condition": "Comunicación estable y centralizada",
    "risk_if_ignored": "Ruido operativo y errores por mala comunicación",
    "sequence": [
      "Definir canal oficial",
      "Implementar reunión diaria",
      "Eliminar órdenes por WhatsApp"
    ],
    "impact_level": "medio",
    "timeframe": "1 semana"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Comunicación",
    "master_decision_explanation": "Evitar ruido operativo",
    "master_action": "Estandarizar reuniones",
    "master_action_explanation": "Aumenta alineación",
    "master_tool": "Radar de Comunicación",
    "master_tool_explanation": "Monitoriza control real"
  },

  "inputs": {
    "input_a": "Datos Necesarios",
    "input_b": "Datos Reales",
    "formula": "Datos Reales / Datos Necesarios",
    "impact": "Nivel de Control: Capacidad real de pilotar el negocio"
  },

  "review": {
    "input_revised_1": "Datos Necesarios Post",
    "input_revised_2": "Datos Reales Post",
    "result_revised": "Control Mejorado"
  }
},
{
  "id": "UNI-S9",
  "name": "Mantenimiento Deficiente",
  "specialty": "procesos",
  "plan": "PRE",
  "domain": "mantenimiento",
  "description": "Activos sin revisión que generan averías y paradas.",

  "kpi": {
    "question": "¿Cuánto dependes del dueño para operar?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Plan preventivo",
    "decision_explanation": "Evitar paradas por avería",
    "action": "Calendario de revisiones de activos clave",
    "action_explanation": "Evita fallos críticos",
    "tool": "Plan de Prevención",
    "tool_explanation": "Estructura mantenimiento",

    "objective": "Aumentar autonomía operativa",
    "kpi_target": "Libertad > 60%",
    "activation_condition": "Libertad < 40%",
    "success_condition": "Dueño fuera de la operativa diaria",
    "risk_if_ignored": "Paradas críticas y dependencia extrema",
    "sequence": [
      "Identificar activos clave",
      "Programar revisiones",
      "Automatizar recordatorios"
    ],
    "impact_level": "alto",
    "timeframe": "3 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Activos",
    "master_decision_explanation": "Asegurar continuidad operativa",
    "master_action": "Automatizar revisiones",
    "master_action_explanation": "Evita fallos humanos",
    "master_tool": "Radar de Activos",
    "master_tool_explanation": "Monitoriza estado real"
  },

  "inputs": {
    "input_a": "Tiempo Dueño",
    "input_b": "Horas Mes",
    "formula": "100 - ((Dueño / Mes) x 100)",
    "impact": "Sello S10 Operativo: % de Libertad del dueño"
  },

  "review": {
    "input_revised_1": "Dueño Post",
    "input_revised_2": "Mes Post",
    "result_revised": "Libertad Aumentada"
  }
},
{
  "id": "UNI-S10",
  "name": "Techo Operativo",
  "specialty": "procesos",
  "plan": "PRE",
  "domain": "capacidad",
  "description": "Capacidad insuficiente que limita crecimiento.",

  "kpi": {
    "question": "¿Cuánta energía se pierde en el atasco operativo?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Ingeniería de costes",
    "decision_explanation": "Optimizar capacidad productiva",
    "action": "Rediseñar procesos para reducir coste unitario",
    "action_explanation": "Aumenta eficiencia",
    "tool": "Mapa de Valorización S10",
    "tool_explanation": "Identifica cuellos de botella",

    "objective": "Aumentar eficiencia operativa",
    "kpi_target": "Eficiencia > 80%",
    "activation_condition": "Eficiencia < 60%",
    "success_condition": "Capacidad alineada con demanda",
    "risk_if_ignored": "Estancamiento y pérdida de ventas",
    "sequence": [
      "Medir capacidad real",
      "Identificar cuello de botella",
      "Rediseñar proceso"
    ],
    "impact_level": "alto",
    "timeframe": "4 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Capacidad",
    "master_decision_explanation": "Asegurar escalabilidad operativa",
    "master_action": "Optimizar recursos",
    "master_action_explanation": "Evita saturación",
    "master_tool": "Radar de Capacidad",
    "master_tool_explanation": "Monitoriza eficiencia real"
  },

  "inputs": {
    "input_a": "Capacidad",
    "input_b": "Realidad",
    "formula": "(Realidad / Capacidad) x 100",
    "impact": "% Eficiencia: Cuánta energía se pierde en el atasco"
  },

  "review": {
    "input_revised_1": "Capacidad Post",
    "input_revised_2": "Realidad Post",
    "result_revised": "Eficiencia Mejorada"
  }
}
  ]
},
{
  "specialty": "comercial",
  "symptoms": [
  {
  "id": "CARDIO-S1",
  "name": "Arritmia de Ventas",
  "specialty": "comercial",
  "plan": "PIE",
  "domain": "ventas",
  "description": "Irregularidad en la entrada de clientes y ventas mensuales.",

  "kpi": {
    "question": "¿Tu esfuerzo comercial trae suficientes clientes nuevos?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Radiografía de cartera",
    "decision_explanation": "Detectar clientes activos, dormidos y perdidos",
    "action": "Clasificación de clientes",
    "action_explanation": "Permite priorizar esfuerzos",
    "tool": "Matriz ABC de Clientes",
    "tool_explanation": "Identifica clientes de alto valor",

    "objective": "Aumentar tasa de cierre",
    "kpi_target": "Tasa de cierre > 20%",
    "activation_condition": "Tasa de cierre < 10%",
    "success_condition": "Crecimiento estable de clientes nuevos",
    "risk_if_ignored": "Caída de ventas y dependencia de pocos clientes",
    "sequence": [
      "Clasificar cartera",
      "Detectar clientes dormidos",
      "Reactivar clientes perdidos"
    ],
    "impact_level": "alto",
    "timeframe": "2 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno Comercial",
    "master_decision_explanation": "Asegurar flujo constante de clientes",
    "master_action": "Optimizar pipeline completo",
    "master_action_explanation": "Evita dientes de sierra",
    "master_tool": "Radar Comercial",
    "master_tool_explanation": "Monitoriza salud de ventas"
  },

  "inputs": {
    "input_a": "Nº Prospectos",
    "input_b": "Nº Ventas",
    "formula": "(Ventas / Prospectos) x 100",
    "impact": "Tasa de Cierre: % de efectividad de tu mensaje"
  },

  "review": {
    "input_revised_1": "Prospectos Post",
    "input_revised_2": "Ventas Post",
    "result_revised": "Tasa de Cierre Mejorada"
  }
},
{
  "id": "CARDIO-S2",
  "name": "Fuga de Pacientes",
  "specialty": "comercial",
  "plan": "PIE",
  "domain": "retención",
  "description": "Clientes que dejan de comprar durante largos periodos.",

  "kpi": {
    "question": "¿Qué riesgo tienes si tu cliente principal se va?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Protocolo de rescate",
    "decision_explanation": "Evitar pérdida de clientes",
    "action": "Contacto inmediato con clientes inactivos",
    "action_explanation": "Recupera ventas perdidas",
    "tool": "Plan de Recuperación Flash",
    "tool_explanation": "Activa clientes dormidos",

    "objective": "Reducir dependencia del cliente top",
    "kpi_target": "Riesgo < 20%",
    "activation_condition": "Riesgo > 35%",
    "success_condition": "Cartera diversificada",
    "risk_if_ignored": "Riesgo de quiebra si el cliente top se va",
    "sequence": [
      "Identificar clientes inactivos",
      "Ejecutar protocolo de rescate",
      "Reactivar ventas"
    ],
    "impact_level": "alto",
    "timeframe": "1 semana"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Cartera Comercial",
    "master_decision_explanation": "Evitar dependencia peligrosa",
    "master_action": "Diversificar cartera",
    "master_action_explanation": "Aumenta estabilidad",
    "master_tool": "Radar de Riesgo Comercial",
    "master_tool_explanation": "Monitoriza concentración de ventas"
  },

  "inputs": {
    "input_a": "Venta Cliente Top",
    "input_b": "Venta Total",
    "formula": "(Cliente Top / Venta Total) x 100",
    "impact": "% de Riesgo: Nivel de peligro si ese cliente se va"
  },

  "review": {
    "input_revised_1": "Venta Top Post",
    "input_revised_2": "Venta Total Post",
    "result_revised": "Riesgo Reducido"
  }
},
{
  "id": "CARDIO-S3",
  "name": "Oferta Confusa",
  "specialty": "comercial",
  "plan": "PIE",
  "domain": "producto",
  "description": "El cliente no entiende qué vendes ni por qué debería comprarte.",

  "kpi": {
    "question": "¿Vendes por sistema o por suerte?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Inyección de producto estrella",
    "decision_explanation": "Claridad absoluta en la oferta",
    "action": "Reempaquetar el producto de mayor margen",
    "action_explanation": "Aumenta conversión",
    "tool": "Script de Valor Único",
    "tool_explanation": "Define mensaje claro",

    "objective": "Aumentar estabilidad de ventas",
    "kpi_target": "Ratio estabilidad > 70%",
    "activation_condition": "Ventas muy irregulares",
    "success_condition": "Ventas predecibles",
    "risk_if_ignored": "Dientes de sierra y falta de control",
    "sequence": [
      "Identificar producto estrella",
      "Reempaquetar oferta",
      "Reescribir mensaje comercial"
    ],
    "impact_level": "medio",
    "timeframe": "1 semana"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Oferta Comercial",
    "master_decision_explanation": "Asegurar claridad estratégica",
    "master_action": "Rediseñar catálogo",
    "master_action_explanation": "Evita confusión del cliente",
    "master_tool": "Radar de Oferta Comercial",
    "master_tool_explanation": "Monitoriza estabilidad de ventas"
  },

  "inputs": {
    "input_a": "Ventas Mes 1",
    "input_b": "Ventas Mes 2",
    "formula": "Mes 2 / Mes 1",
    "impact": "Ratio Estabilidad: Nivel de dientes de sierra"
  },

  "review": {
    "input_revised_1": "Ventas Altas Post",
    "input_revised_2": "Ventas Bajas Post",
    "result_revised": "Estabilidad Mejorada"
  }
},
{
  "id": "CARDIO-S4",
  "name": "Pipeline Obstruido",
  "specialty": "comercial",
  "plan": "PRE",
  "domain": "captación",
  "description": "Leads basura y prospección sin calidad.",

  "kpi": {
    "question": "¿Te cuesta más captar un cliente que lo que te deja?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Limpieza de prospección",
    "decision_explanation": "Eliminar leads basura",
    "action": "Priorizar leads de alto potencial",
    "action_explanation": "Aumenta eficiencia comercial",
    "tool": "Embudo de Conversión",
    "tool_explanation": "Evalúa calidad de leads",

    "objective": "Reducir CAC",
    "kpi_target": "CAC < 50€",
    "activation_condition": "CAC > 100€",
    "success_condition": "Prospección rentable",
    "risk_if_ignored": "Pérdida de dinero en captación",
    "sequence": [
      "Analizar leads actuales",
      "Eliminar leads basura",
      "Optimizar embudo"
    ],
    "impact_level": "medio",
    "timeframe": "2 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Captación",
    "master_decision_explanation": "Asegurar rentabilidad comercial",
    "master_action": "Optimizar canales",
    "master_action_explanation": "Reduce coste de adquisición",
    "master_tool": "Radar de CAC",
    "master_tool_explanation": "Monitoriza coste real por cliente"
  },

  "inputs": {
    "input_a": "Gasto Comercial",
    "input_b": "Nº Clientes Nuevos",
    "formula": "Gasto / Clientes Nuevos",
    "impact": "CAC: Coste real de adquirir un cliente"
  },

  "review": {
    "input_revised_1": "Gasto Post",
    "input_revised_2": "Clientes Nuevos Post",
    "result_revised": "CAC Reducido"
  }
},
{
  "id": "CARDIO-S5",
  "name": "Recurrencia Débil",
  "specialty": "comercial",
  "plan": "PRE",
  "domain": "fidelización",
  "description": "Clientes que no repiten compra con regularidad.",

  "kpi": {
    "question": "¿Tus clientes actuales están vivos o muertos?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Plan de fidelización",
    "decision_explanation": "Crear hábito de compra",
    "action": "Implementar ciclos de recompra automática",
    "action_explanation": "Aumenta recurrencia",
    "tool": "Calendario de Contacto",
    "tool_explanation": "Activa recordatorios",

    "objective": "Aumentar ventas recurrentes",
    "kpi_target": "Fidelización > 40%",
    "activation_condition": "Fidelización < 25%",
    "success_condition": "Clientes activos y recurrentes",
    "risk_if_ignored": "Dependencia de clientes nuevos",
    "sequence": [
      "Identificar clientes antiguos",
      "Crear plan de recompra",
      "Automatizar recordatorios"
    ],
    "impact_level": "medio",
    "timeframe": "3 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Fidelización",
    "master_decision_explanation": "Aumentar valor de vida del cliente",
    "master_action": "Optimizar ciclo de recompra",
    "master_action_explanation": "Aumenta recurrencia sostenible",
    "master_tool": "Radar de Fidelización",
    "master_tool_explanation": "Monitoriza ventas recurrentes"
  },

  "inputs": {
    "input_a": "Ventas Clientes Antiguos",
    "input_b": "Venta Total",
    "formula": "(Ventas Ant. / Total) x 100",
    "impact": "% Fidelización: Salud de tu cartera recurrente"
  },

  "review": {
    "input_revised_1": "Ventas Antiguos Post",
    "input_revised_2": "Ventas Totales Post",
    "result_revised": "Fidelización Mejorada"
  }
},
{
  "id": "CARDIO-S6",
  "name": "Ticket Medio Bajo",
  "specialty": "comercial",
  "plan": "PRE",
  "domain": "precio",
  "description": "El valor medio de cada venta es demasiado bajo para sostener el negocio.",

  "kpi": {
    "question": "¿Tu precio está fuera de mercado o es demasiado bajo?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Estrategia de upsell/cross-sell",
    "decision_explanation": "Vender más al mismo cliente",
    "action": "Diseñar ofertas complementarias",
    "action_explanation": "Aumenta ticket medio",
    "tool": "Matriz de Venta Cruzada",
    "tool_explanation": "Detecta combinaciones rentables",

    "objective": "Aumentar ticket medio",
    "kpi_target": "Ticket medio > 20% del actual",
    "activation_condition": "Ticket medio estancado",
    "success_condition": "Ticket medio creciente y estable",
    "risk_if_ignored": "Necesidad de captar más clientes para sobrevivir",
    "sequence": [
      "Analizar productos complementarios",
      "Crear combos de valor",
      "Ofrecer upsell en cada venta"
    ],
    "impact_level": "medio",
    "timeframe": "2 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Precio",
    "master_decision_explanation": "Asegurar precios alineados al valor",
    "master_action": "Optimizar estrategia de precios",
    "master_action_explanation": "Evita ser demasiado barato",
    "master_tool": "Radar de Precio",
    "master_tool_explanation": "Monitoriza aceptación del mercado"
  },

  "inputs": {
    "input_a": "Presupuestos Aceptados",
    "input_b": "Presupuestos Totales",
    "formula": "(Aceptados / Totales) x 100",
    "impact": "Termómetro Precio: Si cierras el 100%, eres demasiado barato"
  },

  "review": {
    "input_revised_1": "Aceptados Post",
    "input_revised_2": "Totales Post",
    "result_revised": "Precio Optimizado"
  }
},
{
  "id": "CARDIO-S7",
  "name": "Seguimiento Inexistente",
  "specialty": "comercial",
  "plan": "PRE",
  "domain": "postventa",
  "description": "No existe un sistema de seguimiento tras la primera venta.",

  "kpi": {
    "question": "¿Sabes cuánto vale cada operación realmente?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Automatización de hitos",
    "decision_explanation": "Evitar olvidos y pérdidas de clientes",
    "action": "Configurar secuencias de seguimiento",
    "action_explanation": "Aumenta recurrencia",
    "tool": "Protocolo de Post-Venta",
    "tool_explanation": "Define pasos claros",

    "objective": "Aumentar ticket medio y recurrencia",
    "kpi_target": "Ticket medio > 15% del actual",
    "activation_condition": "Ticket medio bajo",
    "success_condition": "Seguimiento consistente",
    "risk_if_ignored": "Clientes que no vuelven",
    "sequence": [
      "Definir hitos postventa",
      "Automatizar recordatorios",
      "Medir recurrencia"
    ],
    "impact_level": "medio",
    "timeframe": "2 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Postventa",
    "master_decision_explanation": "Aumentar valor de vida del cliente",
    "master_action": "Optimizar experiencia postventa",
    "master_action_explanation": "Aumenta fidelización",
    "master_tool": "Radar de Postventa",
    "master_tool_explanation": "Monitoriza recurrencia real"
  },

  "inputs": {
    "input_a": "Facturación Total",
    "input_b": "Nº Facturas",
    "formula": "Facturación / Nº Facturas",
    "impact": "Ticket Medio: Valor real de cada operación"
  },

  "review": {
    "input_revised_1": "Facturación Post",
    "input_revised_2": "Facturas Post",
    "result_revised": "Ticket Medio Mejorado"
  }
},
{
  "id": "CARDIO-S8",
  "name": "Dependencia de Canal",
  "specialty": "comercial",
  "plan": "PRE",
  "domain": "captación",
  "description": "Dependencia excesiva de un único canal de captación.",

  "kpi": {
    "question": "¿Cuánto tardas en enamorar al cliente?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Diversificación comercial",
    "decision_explanation": "Abrir nuevas vías de captación",
    "action": "Testar un nuevo canal",
    "action_explanation": "Reduce riesgo",
    "tool": "Mapa de Canales de Ingreso",
    "tool_explanation": "Evalúa canales alternativos",

    "objective": "Reducir dependencia de un solo canal",
    "kpi_target": "Ciclo de venta < 20 días",
    "activation_condition": "Ciclo de venta > 30 días",
    "success_condition": "Captación diversificada",
    "risk_if_ignored": "Riesgo extremo si el canal principal falla",
    "sequence": [
      "Analizar canal actual",
      "Testar canal alternativo",
      "Medir conversión"
    ],
    "impact_level": "medio",
    "timeframe": "3 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Canales",
    "master_decision_explanation": "Asegurar flujo estable de clientes",
    "master_action": "Diversificar canales",
    "master_action_explanation": "Evita dependencia peligrosa",
    "master_tool": "Radar de Canales",
    "master_tool_explanation": "Monitoriza rendimiento por canal"
  },

  "inputs": {
    "input_a": "Día 1er Contacto",
    "input_b": "Día de Pago",
    "formula": "Día Pago - Día Contacto",
    "impact": "Ciclo de Venta: Días que tarda tu dinero en volver a casa"
  },

  "review": {
    "input_revised_1": "Contacto Post",
    "input_revised_2": "Pago Post",
    "result_revised": "Ciclo Reducido"
  }
},
{
  "id": "CARDIO-S9",
  "name": "Mensaje Inefectivo",
  "specialty": "comercial",
  "plan": "PRE",
  "domain": "comunicación",
  "description": "El mensaje comercial no conecta con el cliente ideal.",

  "kpi": {
    "question": "¿Sabes por qué no te compran?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Optimización de conversión",
    "decision_explanation": "Hablar al dolor real del cliente",
    "action": "Cambiar enfoque de 'lo que hago' a 'lo que resuelvo'",
    "action_explanation": "Aumenta conversión",
    "tool": "Guía de Objeciones y Cierre",
    "tool_explanation": "Mejora argumentario",

    "objective": "Aumentar aprendizaje comercial",
    "kpi_target": "Nivel de aprendizaje > 50%",
    "activation_condition": "Motivos identificados < 20%",
    "success_condition": "Mensaje alineado al cliente ideal",
    "risk_if_ignored": "Pérdida de ventas por mala comunicación",
    "sequence": [
      "Registrar objeciones",
      "Clasificar motivos de no compra",
      "Reescribir mensaje"
    ],
    "impact_level": "medio",
    "timeframe": "2 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Mensaje",
    "master_decision_explanation": "Asegurar claridad y persuasión",
    "master_action": "Optimizar narrativa comercial",
    "master_action_explanation": "Aumenta conversión sostenible",
    "master_tool": "Radar de Mensaje",
    "master_tool_explanation": "Monitoriza efectividad del discurso"
  },

  "inputs": {
    "input_a": "Ventas Perdidas",
    "input_b": "Motivos Identificados",
    "formula": "(Motivos / Perdidas) x 100",
    "impact": "Nivel de Aprendizaje: Capacidad de mejorar el producto"
  },

  "review": {
    "input_revised_1": "Perdidas Post",
    "input_revised_2": "Motivos Post",
    "result_revised": "Aprendizaje Mejorado"
  }
},
{
  "id": "CARDIO-S10",
  "name": "Venta Errática",
  "specialty": "comercial",
  "plan": "PRE",
  "domain": "excelencia",
  "description": "Ventas inestables y dependientes del azar o del dueño.",

  "kpi": {
    "question": "¿Cuánta fuerza tiene tu marca sin que tú estés presente?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Optimización del LTV",
    "decision_explanation": "Aumentar valor de vida del cliente",
    "action": "Implementar sistema de lealtad",
    "action_explanation": "Aumenta recurrencia",
    "tool": "Pirámide de Fidelización",
    "tool_explanation": "Define niveles de lealtad",

    "objective": "Aumentar ventas orgánicas",
    "kpi_target": "Referidos > 20%",
    "activation_condition": "Referidos < 10%",
    "success_condition": "Marca que se recomienda sola",
    "risk_if_ignored": "Dependencia del dueño para vender",
    "sequence": [
      "Crear programa de referidos",
      "Incentivar recomendaciones",
      "Medir ventas orgánicas"
    ],
    "impact_level": "alto",
    "timeframe": "4 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Marca Comercial",
    "master_decision_explanation": "Aumentar reputación y autoridad",
    "master_action": "Optimizar reputación",
    "master_action_explanation": "Aumenta ventas orgánicas",
    "master_tool": "Radar de Marca",
    "master_tool_explanation": "Monitoriza reputación real"
  },

  "inputs": {
    "input_a": "Ventas de Referidos",
    "input_b": "Venta Total",
    "formula": "(Referidos / Total) x 100",
    "impact": "Sello S10 Comercial: Poder de tu marca"
  },

  "review": {
    "input_revised_1": "Referidos Post",
    "input_revised_2": "Total Post",
    "result_revised": "Marca Fortalecida"
  }
}
  ]
},
{  "specialty": "estrategia",
  "symptoms": [
  {
  "id": "NEURO-S1",
  "name": "Amnesia de Visión",
  "specialty": "estrategia",
  "plan": "PIE",
  "domain": "visión",
  "description": "El equipo no recuerda ni comparte el rumbo estratégico del negocio.",

  "kpi": {
    "question": "¿El equipo rema hacia el mismo lugar?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Fijación de rumbo",
    "decision_explanation": "Recordar y comunicar el norte estratégico",
    "action": "Entrevista de alineación con el comité",
    "action_explanation": "Asegura claridad colectiva",
    "tool": "Manifiesto de Visión 1-Page",
    "tool_explanation": "Resume el rumbo en una sola página",

    "objective": "Aumentar alineación estratégica",
    "kpi_target": "% Alineación > 80%",
    "activation_condition": "% Alineación < 60%",
    "success_condition": "Equipo alineado con la visión anual",
    "risk_if_ignored": "Descoordinación y pérdida de foco",
    "sequence": [
      "Definir visión anual",
      "Comunicar visión al equipo",
      "Validar comprensión"
    ],
    "impact_level": "alto",
    "timeframe": "1 semana"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Visión",
    "master_decision_explanation": "Asegurar claridad estratégica permanente",
    "master_action": "Reforzar visión trimestral",
    "master_action_explanation": "Evita deriva estratégica",
    "master_tool": "Radar de Alineación",
    "master_tool_explanation": "Monitoriza comprensión del equipo"
  },

  "inputs": {
    "input_a": "Objetivos Año",
    "input_b": "Objetivos Conocidos",
    "formula": "(Conocidos / Año) x 100",
    "impact": "% Alineación: Fuerza de empuje de la organización"
  },

  "review": {
    "input_revised_1": "Objetivos Año Post",
    "input_revised_2": "Objetivos Conocidos Post",
    "result_revised": "Alineación Mejorada"
  }
},
{
  "id": "NEURO-S2",
  "name": "Dispersión de Foco",
  "specialty": "estrategia",
  "plan": "PIE",
  "domain": "priorización",
  "description": "Demasiados proyectos abiertos sin impacto real.",

  "kpi": {
    "question": "¿Estás mirando el suelo o el horizonte?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Corte de ramas",
    "decision_explanation": "Eliminar proyectos lastre",
    "action": "Listar proyectos y filtrar por impacto",
    "action_explanation": "Aumenta foco estratégico",
    "tool": "Matriz de Priorización (Impacto/Esfuerzo)",
    "tool_explanation": "Identifica proyectos clave",

    "objective": "Aumentar tiempo estratégico",
    "kpi_target": "Ratio de visión > 30%",
    "activation_condition": "Horas estrategia < 15%",
    "success_condition": "Foco estratégico recuperado",
    "risk_if_ignored": "Agotamiento y falta de dirección",
    "sequence": [
      "Listar proyectos activos",
      "Eliminar proyectos sin impacto",
      "Priorizar proyectos clave"
    ],
    "impact_level": "alto",
    "timeframe": "1 semana"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Prioridades",
    "master_decision_explanation": "Asegurar foco estratégico continuo",
    "master_action": "Revisión mensual de prioridades",
    "master_action_explanation": "Evita dispersión futura",
    "master_tool": "Radar de Prioridades",
    "master_tool_explanation": "Monitoriza foco real"
  },

  "inputs": {
    "input_a": "Horas Operativa",
    "input_b": "Horas Estrategia",
    "formula": "(Estrategia / Operativa) x 100",
    "impact": "Ratio de Visión: Capacidad de anticiparse a problemas"
  },

  "review": {
    "input_revised_1": "Operativa Post",
    "input_revised_2": "Estrategia Post",
    "result_revised": "Foco Recuperado"
  }
},
{
  "id": "NEURO-S3",
  "name": "Improvisación",
  "specialty": "estrategia",
  "plan": "PIE",
  "domain": "planificación",
  "description": "La empresa opera sin hoja de ruta clara.",

  "kpi": {
    "question": "¿Tu catálogo está alineado al futuro o al pasado?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Sincronización de agenda",
    "decision_explanation": "Definir hitos innegociables",
    "action": "Definir los 3 hitos del trimestre",
    "action_explanation": "Aumenta claridad operativa",
    "tool": "Roadmap Estratégico",
    "tool_explanation": "Define ruta trimestral",

    "objective": "Aumentar enfoque estratégico",
    "kpi_target": "Índice de enfoque > 70%",
    "activation_condition": "Índice < 50%",
    "success_condition": "Catálogo alineado al futuro",
    "risk_if_ignored": "Desorden y pérdida de competitividad",
    "sequence": [
      "Definir hitos trimestrales",
      "Asignar responsables",
      "Revisar avance semanal"
    ],
    "impact_level": "medio",
    "timeframe": "2 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Ruta Estratégica",
    "master_decision_explanation": "Asegurar avance continuo",
    "master_action": "Revisión trimestral de roadmap",
    "master_action_explanation": "Evita improvisación futura",
    "master_tool": "Radar de Ruta",
    "master_tool_explanation": "Monitoriza avance estratégico"
  },

  "inputs": {
    "input_a": "Nº de Servicios",
    "input_b": "Servicios Rentables",
    "formula": "Rentables / Totales",
    "impact": "Índice de Enfoque: Limpieza de la paja en el catálogo"
  },

  "review": {
    "input_revised_1": "Servicios Post",
    "input_revised_2": "Rentables Post",
    "result_revised": "Enfoque Mejorado"
  }
},
{
  "id": "NEURO-S4",
  "name": "Intuición sin Datos",
  "specialty": "estrategia",
  "plan": "PRE",
  "domain": "datos",
  "description": "Decisiones estratégicas basadas en intuición en lugar de datos reales.",

  "kpi": {
    "question": "¿Mides lo suficiente para tomar decisiones?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Objetivación del éxito",
    "decision_explanation": "Medir o morir",
    "action": "Identificar los 5 KPIs maestros",
    "action_explanation": "Aumenta claridad estratégica",
    "tool": "Dashboard de Mando Neuro",
    "tool_explanation": "Centraliza datos clave",

    "objective": "Aumentar diversificación estratégica",
    "kpi_target": "% Diversificación > 30%",
    "activation_condition": "% Diversificación < 15%",
    "success_condition": "Negocio resistente a crisis sectoriales",
    "risk_if_ignored": "Vulnerabilidad ante cambios del mercado",
    "sequence": [
      "Identificar KPIs maestros",
      "Construir dashboard",
      "Revisar datos semanalmente"
    ],
    "impact_level": "alto",
    "timeframe": "2 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Datos",
    "master_decision_explanation": "Asegurar decisiones basadas en evidencia",
    "master_action": "Revisión mensual de KPIs",
    "master_action_explanation": "Evita decisiones impulsivas",
    "master_tool": "Radar de Datos",
    "master_tool_explanation": "Monitoriza salud estratégica"
  },

  "inputs": {
    "input_a": "Ventas Sector A",
    "input_b": "Ventas Sector B",
    "formula": "(Sector B / Total) x 100",
    "impact": "% Diversificación: Seguro de vida ante crisis externas"
  },

  "review": {
    "input_revised_1": "Sector A Post",
    "input_revised_2": "Sector B Post",
    "result_revised": "Diversificación Mejorada"
  }
},
{
  "id": "NEURO-S5",
  "name": "Fatiga Decisoria",
  "specialty": "estrategia",
  "plan": "PRE",
  "domain": "decisión",
  "description": "El dueño toma demasiadas decisiones sin un sistema claro.",

  "kpi": {
    "question": "¿Innovas o repites lo mismo de hace 10 años?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Protocolo de decisión",
    "decision_explanation": "Agilizar el juicio",
    "action": "Implementar criterios para el SÍ",
    "action_explanation": "Reduce desgaste mental",
    "tool": "Árbol de Decisión MASESORA",
    "tool_explanation": "Estandariza decisiones",

    "objective": "Aumentar innovación",
    "kpi_target": "Innovación > 20%",
    "activation_condition": "Innovación < 10%",
    "success_condition": "Decisiones rápidas y alineadas",
    "risk_if_ignored": "Bloqueo mental y estancamiento",
    "sequence": [
      "Definir criterios de decisión",
      "Aplicar árbol de decisión",
      "Revisar impacto mensual"
    ],
    "impact_level": "medio",
    "timeframe": "2 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Decisiones",
    "master_decision_explanation": "Asegurar decisiones coherentes",
    "master_action": "Optimizar sistema de decisión",
    "master_action_explanation": "Evita desgaste mental",
    "master_tool": "Radar de Decisión",
    "master_tool_explanation": "Monitoriza calidad de decisiones"
  },

  "inputs": {
    "input_a": "Ventas Productos Nuevos",
    "input_b": "Venta Total",
    "formula": "(Nuevos / Total) x 100",
    "impact": "Ratio Innovación: Capacidad de no quedarse obsoleto"
  },

  "review": {
    "input_revised_1": "Nuevos Post",
    "input_revised_2": "Total Post",
    "result_revised": "Innovación Mejorada"
  }
},
{
  "id": "NEURO-S6",
  "name": "Silos Cognitivos",
  "specialty": "estrategia",
  "plan": "PRE",
  "domain": "interconexión",
  "description": "Departamentos que no comparten información ni trabajan alineados.",

  "kpi": {
    "question": "¿Tu empresa puede crecer sin que tú mueras en el intento?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Interconexión departamental",
    "decision_explanation": "Crear sinapsis entre áreas",
    "action": "Reunión de alineación cruzada",
    "action_explanation": "Evita duplicidades y errores",
    "tool": "Mapa de Dependencias",
    "tool_explanation": "Visualiza conexiones entre áreas",

    "objective": "Aumentar escalabilidad",
    "kpi_target": "Índice de escala > 30%",
    "activation_condition": "Índice de escala < 15%",
    "success_condition": "Departamentos conectados y alineados",
    "risk_if_ignored": "Crecimiento que aumenta el gasto más que la venta",
    "sequence": [
      "Mapear dependencias",
      "Detectar cuellos de comunicación",
      "Establecer reuniones cruzadas"
    ],
    "impact_level": "alto",
    "timeframe": "2 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Sinapsis",
    "master_decision_explanation": "Asegurar interconexión permanente",
    "master_action": "Optimizar comunicación entre áreas",
    "master_action_explanation": "Evita silos futuros",
    "master_tool": "Radar de Sinapsis",
    "master_tool_explanation": "Monitoriza conexiones reales"
  },

  "inputs": {
    "input_a": "Nuevas Ventas",
    "input_b": "Coste Estructura",
    "formula": "Venta / Coste Estructura",
    "impact": "Índice de Escala: Si el gasto sube más que la venta, no escalas"
  },

  "review": {
    "input_revised_1": "Ventas Post",
    "input_revised_2": "Coste Post",
    "result_revised": "Escala Mejorada"
  }
},
{
  "id": "NEURO-S7",
  "name": "Resistencia al Cambio",
  "specialty": "estrategia",
  "plan": "PRE",
  "domain": "adaptabilidad",
  "description": "El equipo o el dueño rechazan cambios necesarios para crecer.",

  "kpi": {
    "question": "¿Tu negocio depende de favores o de tu sistema?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Neuro-plasticidad",
    "decision_explanation": "Aumentar adaptabilidad",
    "action": "Taller de gestión del cambio",
    "action_explanation": "Reduce resistencia",
    "tool": "Plan de Adopción de Estrategia",
    "tool_explanation": "Guía implementación del cambio",

    "objective": "Aumentar autonomía del negocio",
    "kpi_target": "Autonomía > 60%",
    "activation_condition": "Autonomía < 40%",
    "success_condition": "Negocio que funciona por sistema",
    "risk_if_ignored": "Dependencia de contactos o favores",
    "sequence": [
      "Identificar resistencias",
      "Aplicar taller de cambio",
      "Revisar adopción"
    ],
    "impact_level": "medio",
    "timeframe": "3 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Adaptación",
    "master_decision_explanation": "Asegurar evolución continua",
    "master_action": "Optimizar adopción estratégica",
    "master_action_explanation": "Evita estancamiento",
    "master_tool": "Radar de Adaptación",
    "master_tool_explanation": "Monitoriza adopción real"
  },

  "inputs": {
    "input_a": "Ventas por Contacto",
    "input_b": "Ventas por Sistema",
    "formula": "Sistema / Total",
    "impact": "Grado de Autonomía: Valor real del negocio en el mercado"
  },

  "review": {
    "input_revised_1": "Sistema Post",
    "input_revised_2": "Total Post",
    "result_revised": "Autonomía Mejorada"
  }
},
{
  "id": "NEURO-S8",
  "name": "Incoherencia Táctica",
  "specialty": "estrategia",
  "plan": "PRE",
  "domain": "alineación",
  "description": "Las tareas del equipo no suman al KPI estratégico.",

  "kpi": {
    "question": "¿Cuánto tardas desde la idea hasta el cambio real?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Alineación vertical",
    "decision_explanation": "Conectar tareas con objetivos",
    "action": "Revisar que las tareas sumen al KPI",
    "action_explanation": "Aumenta coherencia operativa",
    "tool": "Cascada de Objetivos (OKR)",
    "tool_explanation": "Alinea tareas con estrategia",

    "objective": "Aumentar agilidad estratégica",
    "kpi_target": "Agilidad < 10 días",
    "activation_condition": "Agilidad > 20 días",
    "success_condition": "Ejecución rápida y alineada",
    "risk_if_ignored": "Ideas que nunca se ejecutan",
    "sequence": [
      "Revisar tareas actuales",
      "Eliminar tareas incoherentes",
      "Alinear tareas con OKR"
    ],
    "impact_level": "alto",
    "timeframe": "1 semana"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Alineación",
    "master_decision_explanation": "Asegurar coherencia continua",
    "master_action": "Optimizar OKRs trimestrales",
    "master_action_explanation": "Evita incoherencias futuras",
    "master_tool": "Radar de Alineación Táctica",
    "master_tool_explanation": "Monitoriza velocidad de ejecución"
  },

  "inputs": {
    "input_a": "Día de Idea",
    "input_b": "Día de Ejecución",
    "formula": "Día Ejecución - Día Idea",
    "impact": "Agilidad Estratégica: Velocidad para pivotar y ganar"
  },

  "review": {
    "input_revised_1": "Idea Post",
    "input_revised_2": "Ejecución Post",
    "result_revised": "Agilidad Mejorada"
  }
},
{
  "id": "NEURO-S9",
  "name": "Cortoplacismo",
  "specialty": "estrategia",
  "plan": "PRE",
  "domain": "visión",
  "description": "El negocio toma decisiones mirando solo el corto plazo.",

  "kpi": {
    "question": "¿Cuál es tu ventaja real sobre los demás?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Visión prospectiva",
    "decision_explanation": "Mirar al horizonte",
    "action": "Sesión de análisis de amenazas y oportunidades",
    "action_explanation": "Aumenta visión estratégica",
    "tool": "Matriz DAFO Dinámica",
    "tool_explanation": "Evalúa entorno competitivo",

    "objective": "Aumentar ventaja competitiva",
    "kpi_target": "Foso defensivo > 20%",
    "activation_condition": "Foso < 10%",
    "success_condition": "Ventaja competitiva clara",
    "risk_if_ignored": "Ser copiable y perder mercado",
    "sequence": [
      "Analizar amenazas",
      "Analizar oportunidades",
      "Definir ventaja competitiva"
    ],
    "impact_level": "medio",
    "timeframe": "2 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno Competitivo",
    "master_decision_explanation": "Asegurar ventaja sostenible",
    "master_action": "Optimizar propuesta de valor",
    "master_action_explanation": "Evita ser uno más",
    "master_tool": "Radar Competitivo",
    "master_tool_explanation": "Monitoriza diferenciación"
  },

  "inputs": {
    "input_a": "Tu Valor Único",
    "input_b": "Copias",
    "formula": "1 / Copias",
    "impact": "Foso Defensivo: Dificultad para quitarte el sitio"
  },

  "review": {
    "input_revised_1": "Valor Post",
    "input_revised_2": "Copias Post",
    "result_revised": "Foso Mejorado"
  }
},
{
  "id": "NEURO-S10",
  "name": "Cerebro Alineado",
  "specialty": "estrategia",
  "plan": "PRE",
  "domain": "excelencia",
  "description": "Nivel 10: claridad total y alineación estratégica del 100% del equipo.",

  "kpi": {
    "question": "¿Qué multiplicador real tiene tu empresa?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Certificación de foco estratégico",
    "decision_explanation": "Asegurar claridad total",
    "action": "Evaluación de alineación del 100% del equipo",
    "action_explanation": "Garantiza coherencia total",
    "tool": "Certificado de Foco Estratégico",
    "tool_explanation": "Valida alineación real",

    "objective": "Aumentar valor de venta del negocio",
    "kpi_target": "Multiplicador > 3x",
    "activation_condition": "Multiplicador < 2x",
    "success_condition": "Empresa vendible como activo",
    "risk_if_ignored": "Negocio dependiente del dueño",
    "sequence": [
      "Evaluar alineación del equipo",
      "Corregir incoherencias",
      "Certificar foco estratégico"
    ],
    "impact_level": "alto",
    "timeframe": "4 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Excelencia Estratégica",
    "master_decision_explanation": "Convertir la empresa en un activo vendible",
    "master_action": "Optimizar valor de venta",
    "master_action_explanation": "Aumenta riqueza real del dueño",
    "master_tool": "Radar S10 Estrategia",
    "master_tool_explanation": "Monitoriza multiplicador real"
  },

  "inputs": {
    "input_a": "Valor de Venta",
    "input_b": "Inversión Dueño",
    "formula": "Valor / Inversión",
    "impact": "Sello S10 Estrategia: Multiplicador de riqueza real"
  },

  "review": {
    "input_revised_1": "Valor Post",
    "input_revised_2": "Inversión Post",
    "result_revised": "Multiplicador Mejorado"
  }
}
  ]
},
{
  "specialty": "gestion",
  "symptoms": [
  {
  "id": "CLI-S1",
  "name": "Infarto por Urgencias",
  "specialty": "gestion",
  "plan": "PIE",
  "domain": "operativa",
  "description": "La empresa vive apagando fuegos y reaccionando tarde a los problemas.",

  "kpi": {
    "question": "¿Cierras el mes el día 1 o el día 20?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Drenaje de incendios",
    "decision_explanation": "Separar operar de gestionar",
    "action": "Clasificar tareas en Operar vs. Gestionar",
    "action_explanation": "Reduce urgencias y caos",
    "tool": "Matriz de Intervención Crítica",
    "tool_explanation": "Identifica tareas que generan incendios",

    "objective": "Aumentar velocidad de datos",
    "kpi_target": "Cierre < 5 días",
    "activation_condition": "Cierre > 10 días",
    "success_condition": "Cierre mensual rápido y estable",
    "risk_if_ignored": "Ceguera financiera y decisiones tardías",
    "sequence": [
      "Clasificar tareas",
      "Eliminar urgencias recurrentes",
      "Crear agenda de gestión"
    ],
    "impact_level": "alto",
    "timeframe": "1 semana"
  },

  "master_treatment": {
    "master_decision": "Gobierno Operativo",
    "master_decision_explanation": "Asegurar control del negocio",
    "master_action": "Optimizar sistema de cierre",
    "master_action_explanation": "Evita retrasos futuros",
    "master_tool": "Radar de Cierre",
    "master_tool_explanation": "Monitoriza velocidad de datos"
  },

  "inputs": {
    "input_a": "Día de Cierre",
    "input_b": "Día 1",
    "formula": "Día de Cierre - Día 1",
    "impact": "Velocidad de Datos: Capacidad de reaccionar antes del desastre"
  },

  "review": {
    "input_revised_1": "Cierre Post",
    "input_revised_2": "Inicio Mes Post",
    "result_revised": "Velocidad Mejorada"
  }
},
{
  "id": "CLI-S2",
  "name": "Esclerosis Documental",
  "specialty": "gestion",
  "plan": "PIE",
  "domain": "información",
  "description": "La información está dispersa y no se encuentra cuando se necesita.",

  "kpi": {
    "question": "¿Tu cuadro de mandos es útil o es basura?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Fluidez de información",
    "decision_explanation": "Organizar el cerebro digital",
    "action": "Unificar nube y estructura documental",
    "action_explanation": "Evita pérdidas de tiempo",
    "tool": "Estructura de Archivo Único",
    "tool_explanation": "Centraliza la información",

    "objective": "Aumentar utilidad del cuadro de mandos",
    "kpi_target": "% Utilidad > 50%",
    "activation_condition": "% Utilidad < 30%",
    "success_condition": "Datos útiles y accesibles",
    "risk_if_ignored": "Decisiones basadas en datos incorrectos",
    "sequence": [
      "Auditar archivos",
      "Unificar estructura",
      "Eliminar duplicados"
    ],
    "impact_level": "medio",
    "timeframe": "2 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Información",
    "master_decision_explanation": "Asegurar datos limpios",
    "master_action": "Optimizar cuadro de mandos",
    "master_action_explanation": "Evita ruido informativo",
    "master_tool": "Radar de KPIs",
    "master_tool_explanation": "Monitoriza utilidad real"
  },

  "inputs": {
    "input_a": "Indicadores Totales",
    "input_b": "Decisiones Tomadas",
    "formula": "(Decisiones / Datos) x 100",
    "impact": "% de Utilidad: Eficiencia del sistema de control"
  },

  "review": {
    "input_revised_1": "Indicadores Post",
    "input_revised_2": "Decisiones Post",
    "result_revised": "Utilidad Mejorada"
  }
},
{
  "id": "CLI-S3",
  "name": "Atrofia de Tiempos",
  "specialty": "gestion",
  "plan": "PIE",
  "domain": "tiempo",
  "description": "El dueño pierde horas en tareas que no generan valor.",

  "kpi": {
    "question": "¿Estás al día con Hacienda y normativas?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Recuperación de autonomía",
    "decision_explanation": "Liberar tiempo del dueño",
    "action": "Identificar tareas que roban el 80% del tiempo",
    "action_explanation": "Aumenta productividad",
    "tool": "Cronograma de Rescate",
    "tool_explanation": "Detecta ladrones de tiempo",

    "objective": "Aumentar seguridad legal",
    "kpi_target": "Índice de seguridad > 90%",
    "activation_condition": "Índice < 70%",
    "success_condition": "Obligaciones al día",
    "risk_if_ignored": "Multas, sanciones y estrés",
    "sequence": [
      "Listar obligaciones",
      "Revisar cumplimiento",
      "Crear calendario legal"
    ],
    "impact_level": "alto",
    "timeframe": "1 semana"
  },

  "master_treatment": {
    "master_decision": "Gobierno Legal",
    "master_decision_explanation": "Evitar riesgos legales",
    "master_action": "Optimizar sistema de cumplimiento",
    "master_action_explanation": "Evita sustos futuros",
    "master_tool": "Radar Legal",
    "master_tool_explanation": "Monitoriza cumplimiento"
  },

  "inputs": {
    "input_a": "Obligaciones",
    "input_b": "Presentados",
    "formula": "(Presentados / Obligaciones) x 100",
    "impact": "Índice de Seguridad: Protección legal frente a multas"
  },

  "review": {
    "input_revised_1": "Obligaciones Post",
    "input_revised_2": "Presentados Post",
    "result_revised": "Seguridad Mejorada"
  }
},
{
  "id": "CLI-S4",
  "name": "Memoria Volátil",
  "specialty": "gestion",
  "plan": "PRE",
  "domain": "conocimiento",
  "description": "La empresa depende de la memoria del dueño o del equipo.",

  "kpi": {
    "question": "¿Cuánto dinero pierdes por gasto hormiga?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Fijación de conocimiento",
    "decision_explanation": "Evitar errores por memoria",
    "action": "Protocolizar las 5 acciones que más errores generan",
    "action_explanation": "Aumenta consistencia",
    "tool": "Manual de Supervivencia Operativa",
    "tool_explanation": "Documenta procesos clave",

    "objective": "Reducir fuga silenciosa",
    "kpi_target": "% Fuga < 5%",
    "activation_condition": "% Fuga > 15%",
    "success_condition": "Gasto hormiga controlado",
    "risk_if_ignored": "Pérdida de liquidez sin detectar",
    "sequence": [
      "Identificar gastos varios",
      "Clasificar fugas",
      "Protocolizar acciones"
    ],
    "impact_level": "medio",
    "timeframe": "2 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Conocimiento",
    "master_decision_explanation": "Asegurar procesos estables",
    "master_action": "Optimizar documentación",
    "master_action_explanation": "Evita dependencia de memoria",
    "master_tool": "Radar de Conocimiento",
    "master_tool_explanation": "Monitoriza fugas"
  },

  "inputs": {
    "input_a": "Gastos Varios",
    "input_b": "Gasto Total",
    "formula": "(Varios / Total) x 100",
    "impact": "% de Fuga Silenciosa: Dinero que se pierde por falta de orden"
  },

  "review": {
    "input_revised_1": "Varios Post",
    "input_revised_2": "Total Post",
    "result_revised": "Fuga Reducida"
  }
},
{
  "id": "CLI-S5",
  "name": "Músculo Agotado",
  "specialty": "gestion",
  "plan": "PRE",
  "domain": "automatización",
  "description": "Procesos manuales que consumen energía y tiempo del equipo.",

  "kpi": {
    "question": "¿Tus reuniones sirven o son perder el tiempo?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Sustitución mecánica",
    "decision_explanation": "Automatizar lo repetitivo",
    "action": "Sustituir 1 proceso manual por uno automático",
    "action_explanation": "Aumenta eficiencia",
    "tool": "Diseño de Sinapsis Digital",
    "tool_explanation": "Define automatizaciones clave",

    "objective": "Aumentar operatividad",
    "kpi_target": "Ratio operatividad > 50%",
    "activation_condition": "Operatividad < 30%",
    "success_condition": "Reuniones productivas",
    "risk_if_ignored": "Tiempo perdido y baja eficiencia",
    "sequence": [
      "Identificar procesos manuales",
      "Diseñar automatización",
      "Implementar flujo automático"
    ],
    "impact_level": "medio",
    "timeframe": "3 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Automatización",
    "master_decision_explanation": "Asegurar eficiencia continua",
    "master_action": "Optimizar flujos digitales",
    "master_action_explanation": "Evita desgaste operativo",
    "master_tool": "Radar de Reuniones",
    "master_tool_explanation": "Monitoriza operatividad real"
  },

  "inputs": {
    "input_a": "Horas de Reunión",
    "input_b": "Acuerdos en Acta",
    "formula": "Acuerdos / Horas",
    "impact": "Ratio de Operatividad: Rentabilidad del tiempo de gestión"
  },

  "review": {
    "input_revised_1": "Horas Post",
    "input_revised_2": "Acuerdos Post",
    "result_revised": "Operatividad Mejorada"
  }
},
{
  "id": "CLI-S6",
  "name": "Ceguera de Costes",
  "specialty": "gestion",
  "plan": "PRE",
  "domain": "costes",
  "description": "La empresa desconoce el coste real de sus operaciones y servicios.",

  "kpi": {
    "question": "¿Sabes cuánto te cuesta producir lo que vendes?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Radiografía de costes",
    "decision_explanation": "Identificar costes ocultos",
    "action": "Escandallo de procesos clave",
    "action_explanation": "Revela fugas de rentabilidad",
    "tool": "Mapa de Costes Operativos",
    "tool_explanation": "Desglosa costes reales",

    "objective": "Aumentar control de costes",
    "kpi_target": "Desviación < 10%",
    "activation_condition": "Desviación > 20%",
    "success_condition": "Costes controlados y predecibles",
    "risk_if_ignored": "Pérdida de margen sin explicación",
    "sequence": [
      "Listar procesos clave",
      "Asignar costes reales",
      "Detectar fugas"
    ],
    "impact_level": "alto",
    "timeframe": "2 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Costes",
    "master_decision_explanation": "Asegurar rentabilidad sostenible",
    "master_action": "Optimizar estructura de costes",
    "master_action_explanation": "Evita erosión de margen",
    "master_tool": "Radar de Costes",
    "master_tool_explanation": "Monitoriza desviaciones"
  },

  "inputs": {
    "input_a": "Coste Estimado",
    "input_b": "Coste Real",
    "formula": "((Real - Estimado) / Estimado) x 100",
    "impact": "% Desviación: Nivel de control sobre tus operaciones"
  },

  "review": {
    "input_revised_1": "Estimado Post",
    "input_revised_2": "Real Post",
    "result_revised": "Desviación Reducida"
  }
},
{
  "id": "CLI-S7",
  "name": "Parálisis de Delegación",
  "specialty": "gestion",
  "plan": "PRE",
  "domain": "roles",
  "description": "El dueño retiene tareas que deberían estar delegadas.",

  "kpi": {
    "question": "¿Cuánto tiempo pierdes haciendo tareas que no deberías hacer?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Liberación de carga",
    "decision_explanation": "Delegar tareas impropias del dueño",
    "action": "Crear matriz de delegación",
    "action_explanation": "Aumenta tiempo estratégico",
    "tool": "Matriz RACI",
    "tool_explanation": "Define quién hace qué",

    "objective": "Aumentar tiempo estratégico del dueño",
    "kpi_target": "Tiempo estratégico > 30%",
    "activation_condition": "Tiempo estratégico < 15%",
    "success_condition": "Dueño liberado de tareas operativas",
    "risk_if_ignored": "Estancamiento y agotamiento",
    "sequence": [
      "Listar tareas del dueño",
      "Clasificar por valor",
      "Delegar tareas operativas"
    ],
    "impact_level": "alto",
    "timeframe": "3 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Delegación",
    "master_decision_explanation": "Asegurar continuidad operativa",
    "master_action": "Optimizar estructura de roles",
    "master_action_explanation": "Evita dependencia del dueño",
    "master_tool": "Radar de Delegación",
    "master_tool_explanation": "Monitoriza carga del dueño"
  },

  "inputs": {
    "input_a": "Horas Dueño",
    "input_b": "Horas Estrategia",
    "formula": "(Estrategia / Dueño) x 100",
    "impact": "% Tiempo Estratégico: Capacidad de liderar el futuro"
  },

  "review": {
    "input_revised_1": "Dueño Post",
    "input_revised_2": "Estrategia Post",
    "result_revised": "Delegación Mejorada"
  }
},
{
  "id": "CLI-S8",
  "name": "Reuniones Tóxicas",
  "specialty": "gestion",
  "plan": "PRE",
  "domain": "reuniones",
  "description": "Reuniones largas, improductivas y sin acuerdos claros.",

  "kpi": {
    "question": "¿Tus reuniones generan acuerdos o solo ruido?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Cirugía de reuniones",
    "decision_explanation": "Eliminar reuniones inútiles",
    "action": "Implementar agenda obligatoria",
    "action_explanation": "Aumenta productividad",
    "tool": "Acta de Reunión Efectiva",
    "tool_explanation": "Define acuerdos y responsables",

    "objective": "Aumentar operatividad",
    "kpi_target": "Operatividad > 50%",
    "activation_condition": "Operatividad < 30%",
    "success_condition": "Reuniones productivas y breves",
    "risk_if_ignored": "Pérdida de tiempo y desgaste del equipo",
    "sequence": [
      "Eliminar reuniones sin agenda",
      "Aplicar acta obligatoria",
      "Revisar acuerdos semanalmente"
    ],
    "impact_level": "medio",
    "timeframe": "1 semana"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Reuniones",
    "master_decision_explanation": "Asegurar reuniones de alto valor",
    "master_action": "Optimizar rituales de gestión",
    "master_action_explanation": "Evita reuniones tóxicas",
    "master_tool": "Radar de Reuniones",
    "master_tool_explanation": "Monitoriza operatividad real"
  },

  "inputs": {
    "input_a": "Horas Reunión",
    "input_b": "Acuerdos",
    "formula": "Acuerdos / Horas",
    "impact": "Ratio de Operatividad: Valor generado por hora de reunión"
  },

  "review": {
    "input_revised_1": "Horas Post",
    "input_revised_2": "Acuerdos Post",
    "result_revised": "Operatividad Mejorada"
  }
},
{
  "id": "CLI-S9",
  "name": "Falta de Ritmos de Gestión",
  "specialty": "gestion",
  "plan": "PRE",
  "domain": "ritmos",
  "description": "La empresa no tiene rituales de control, revisión y planificación.",

  "kpi": {
    "question": "¿Tu negocio avanza por sistema o por inercia?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Implantación de rituales",
    "decision_explanation": "Crear ritmos de control",
    "action": "Implementar reunión semanal de gestión",
    "action_explanation": "Aumenta control operativo",
    "tool": "Rituales MASESORA",
    "tool_explanation": "Define cadencias de gestión",

    "objective": "Aumentar control del negocio",
    "kpi_target": "Control > 70%",
    "activation_condition": "Control < 40%",
    "success_condition": "Negocio gestionado por sistema",
    "risk_if_ignored": "Descontrol y caos operativo",
    "sequence": [
      "Definir rituales",
      "Asignar responsables",
      "Revisar semanalmente"
    ],
    "impact_level": "alto",
    "timeframe": "2 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Ritmos",
    "master_decision_explanation": "Asegurar gestión continua",
    "master_action": "Optimizar cadencias",
    "master_action_explanation": "Evita recaídas",
    "master_tool": "Radar de Ritmos",
    "master_tool_explanation": "Monitoriza cumplimiento"
  },

  "inputs": {
    "input_a": "Rituales Planificados",
    "input_b": "Rituales Cumplidos",
    "formula": "(Cumplidos / Planificados) x 100",
    "impact": "% Control: Nivel real de gestión del negocio"
  },

  "review": {
    "input_revised_1": "Planificados Post",
    "input_revised_2": "Cumplidos Post",
    "result_revised": "Control Mejorado"
  }
},
{
  "id": "CLI-S10",
  "name": "Gestión de Alto Rendimiento",
  "specialty": "gestion",
  "plan": "PRE",
  "domain": "excelencia",
  "description": "Nivel 10: gestión impecable, rituales sólidos y control total del negocio.",

  "kpi": {
    "question": "¿Tu negocio funciona como un reloj suizo?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Certificación de gestión",
    "decision_explanation": "Validar excelencia operativa",
    "action": "Auditoría de ritmos, roles y datos",
    "action_explanation": "Garantiza control total",
    "tool": "Certificado S10 Gestión",
    "tool_explanation": "Evalúa excelencia real",

    "objective": "Aumentar valor del negocio",
    "kpi_target": "Índice S10 > 90%",
    "activation_condition": "Índice < 80%",
    "success_condition": "Gestión de alto rendimiento",
    "risk_if_ignored": "Pérdida de competitividad",
    "sequence": [
      "Auditar gestión",
      "Corregir desviaciones",
      "Certificar S10"
    ],
    "impact_level": "alto",
    "timeframe": "4 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Excelencia Operativa",
    "master_decision_explanation": "Convertir la gestión en una ventaja competitiva",
    "master_action": "Optimizar sistema de gestión",
    "master_action_explanation": "Aumenta valor del negocio",
    "master_tool": "Radar S10 Gestión",
    "master_tool_explanation": "Monitoriza excelencia real"
  },

  "inputs": {
    "input_a": "Ritmos",
    "input_b": "Roles",
    "formula": "(Ritmos + Roles) / 2",
    "impact": "Índice S10 Gestión: Nivel de excelencia operativa"
  },

  "review": {
    "input_revised_1": "Ritmos Post",
    "input_revised_2": "Roles Post",
    "result_revised": "Excelencia Alcanzada"
  }
}
  ]
},
{
  "specialty": "marca",
  "symptoms": [
  {
  "id": "CIR-S1",
  "name": "Imagen Desactualizada",
  "specialty": "marca",
  "plan": "PIE",
  "domain": "identidad",
  "description": "La estética visual de la empresa transmite antigüedad, poca profesionalidad o desconexión con el mercado actual.",

  "kpi": {
    "question": "¿Tu marca parece de este año o de hace diez?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Lifting de identidad",
    "decision_explanation": "Actualizar la estética para alinearla con el mercado actual",
    "action": "Rediseñar elementos visuales clave",
    "action_explanation": "Genera impacto inmediato",
    "tool": "Kit de Identidad Express",
    "tool_explanation": "Define colores, tipografías y estilo actualizado",

    "objective": "Aumentar percepción de valor",
    "kpi_target": "Percepción > 80%",
    "activation_condition": "Percepción < 60%",
    "success_condition": "Marca moderna y coherente",
    "risk_if_ignored": "Sensación de empresa obsoleta",
    "sequence": [
      "Auditar identidad actual",
      "Actualizar elementos visuales",
      "Aplicar coherencia en todos los puntos de contacto"
    ],
    "impact_level": "alto",
    "timeframe": "1 semana"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Identidad",
    "master_decision_explanation": "Mantener la marca siempre actualizada",
    "master_action": "Optimizar coherencia visual anual",
    "master_action_explanation": "Evita envejecimiento de marca",
    "master_tool": "Radar de Identidad",
    "master_tool_explanation": "Monitoriza percepción visual"
  },

  "inputs": {
    "input_a": "Elementos Modernos",
    "input_b": "Elementos Totales",
    "formula": "(Modernos / Totales) x 100",
    "impact": "% Actualización: Nivel de modernidad visual"
  },

  "review": {
    "input_revised_1": "Modernos Post",
    "input_revised_2": "Totales Post",
    "result_revised": "Identidad Actualizada"
  }
},
{
  "id": "CIR-S2",
  "name": "Presentación Pobre",
  "specialty": "marca",
  "plan": "PIE",
  "domain": "presentación",
  "description": "La empresa presenta sus productos o servicios de forma débil, confusa o poco atractiva.",

  "kpi": {
    "question": "¿Tu presentación enamora o duerme?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Reanimación estética",
    "decision_explanation": "Mejorar la presentación para aumentar impacto",
    "action": "Rediseñar presentación comercial",
    "action_explanation": "Aumenta conversión",
    "tool": "Plantilla WOW",
    "tool_explanation": "Estructura visual de alto impacto",

    "objective": "Aumentar conversión comercial",
    "kpi_target": "Conversión > 20%",
    "activation_condition": "Conversión < 10%",
    "success_condition": "Presentación clara y atractiva",
    "risk_if_ignored": "Clientes que no entienden el valor",
    "sequence": [
      "Auditar presentación actual",
      "Rediseñar estructura visual",
      "Aplicar narrativa clara"
    ],
    "impact_level": "alto",
    "timeframe": "1 semana"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Presentación",
    "master_decision_explanation": "Asegurar impacto visual continuo",
    "master_action": "Optimizar presentaciones trimestralmente",
    "master_action_explanation": "Evita presentaciones obsoletas",
    "master_tool": "Radar de Presentación",
    "master_tool_explanation": "Monitoriza impacto visual"
  },

  "inputs": {
    "input_a": "Elementos Claros",
    "input_b": "Elementos Totales",
    "formula": "(Claros / Totales) x 100",
    "impact": "% Claridad: Nivel de comprensión del mensaje"
  },

  "review": {
    "input_revised_1": "Claros Post",
    "input_revised_2": "Totales Post",
    "result_revised": "Presentación Mejorada"
  }
},
{
  "id": "CIR-S3",
  "name": "Marca Incoherente",
  "specialty": "marca",
  "plan": "PIE",
  "domain": "coherencia",
  "description": "La marca se percibe distinta en cada punto de contacto: web, redes, documentos, mensajes.",

  "kpi": {
    "question": "¿Tu marca parece una o parece cinco distintas?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Unificación estética",
    "decision_explanation": "Alinear todos los puntos de contacto",
    "action": "Crear guía de estilo unificada",
    "action_explanation": "Aumenta coherencia",
    "tool": "Manual de Marca Express",
    "tool_explanation": "Define reglas visuales y de tono",

    "objective": "Aumentar coherencia de marca",
    "kpi_target": "Coherencia > 80%",
    "activation_condition": "Coherencia < 60%",
    "success_condition": "Marca sólida y reconocible",
    "risk_if_ignored": "Percepción de desorden y poca profesionalidad",
    "sequence": [
      "Auditar puntos de contacto",
      "Unificar estilo visual",
      "Aplicar guía de marca"
    ],
    "impact_level": "medio",
    "timeframe": "2 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Coherencia",
    "master_decision_explanation": "Mantener identidad sólida",
    "master_action": "Revisión trimestral de coherencia",
    "master_action_explanation": "Evita desviaciones",
    "master_tool": "Radar de Coherencia",
    "master_tool_explanation": "Monitoriza consistencia"
  },

  "inputs": {
    "input_a": "Puntos Coherentes",
    "input_b": "Puntos Totales",
    "formula": "(Coherentes / Totales) x 100",
    "impact": "% Coherencia: Fuerza de identidad visual"
  },

  "review": {
    "input_revised_1": "Coherentes Post",
    "input_revised_2": "Totales Post",
    "result_revised": "Coherencia Mejorada"
  }
},
{
  "id": "CIR-S4",
  "name": "Mensaje Visual Débil",
  "specialty": "marca",
  "plan": "PIE",
  "domain": "comunicación",
  "description": "El mensaje visual no transmite valor, urgencia ni diferenciación.",

  "kpi": {
    "question": "¿Tu marca comunica o solo decora?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Refuerzo visual",
    "decision_explanation": "Convertir estética en comunicación",
    "action": "Rediseñar mensajes visuales clave",
    "action_explanation": "Aumenta impacto y claridad",
    "tool": "Guía de Mensaje Visual",
    "tool_explanation": "Define mensajes visuales estratégicos",

    "objective": "Aumentar impacto comunicativo",
    "kpi_target": "Impacto > 70%",
    "activation_condition": "Impacto < 50%",
    "success_condition": "Mensajes claros y potentes",
    "risk_if_ignored": "Clientes que no entienden el valor",
    "sequence": [
      "Auditar mensajes visuales",
      "Rediseñar piezas clave",
      "Aplicar narrativa visual"
    ],
    "impact_level": "medio",
    "timeframe": "1 semana"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Mensaje Visual",
    "master_decision_explanation": "Asegurar comunicación potente",
    "master_action": "Optimizar narrativa visual",
    "master_action_explanation": "Evita mensajes débiles",
    "master_tool": "Radar de Mensaje Visual",
    "master_tool_explanation": "Monitoriza impacto comunicativo"
  },

  "inputs": {
    "input_a": "Mensajes Claros",
    "input_b": "Mensajes Totales",
    "formula": "(Claros / Totales) x 100",
    "impact": "% Claridad Visual: Fuerza del mensaje"
  },

  "review": {
    "input_revised_1": "Claros Post",
    "input_revised_2": "Totales Post",
    "result_revised": "Mensaje Visual Mejorado"
  }
},
{
  "id": "CIR-S5",
  "name": "Primera Impresión Débil",
  "specialty": "marca",
  "plan": "PRE",
  "domain": "impacto",
  "description": "El cliente no siente un efecto WOW inmediato al conocer la marca.",

  "kpi": {
    "question": "¿Tu marca enamora en 3 segundos?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Shock de impacto",
    "decision_explanation": "Generar un WOW inmediato",
    "action": "Optimizar portada, hero y primeras piezas visuales",
    "action_explanation": "Aumenta atracción instantánea",
    "tool": "Kit de Impacto Inicial",
    "tool_explanation": "Define elementos de alto impacto",

    "objective": "Aumentar atracción inicial",
    "kpi_target": "Impacto > 80%",
    "activation_condition": "Impacto < 60%",
    "success_condition": "WOW inmediato",
    "risk_if_ignored": "Clientes que se van en 3 segundos",
    "sequence": [
      "Auditar primera impresión",
      "Rediseñar elementos iniciales",
      "Testear impacto"
    ],
    "impact_level": "alto",
    "timeframe": "1 semana"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Impacto",
    "master_decision_explanation": "Asegurar efecto WOW continuo",
    "master_action": "Optimizar impacto anual",
    "master_action_explanation": "Evita pérdida de atracción",
    "master_tool": "Radar de Impacto",
    "master_tool_explanation": "Monitoriza fuerza del WOW"
  },

  "inputs": {
    "input_a": "Elementos WOW",
    "input_b": "Elementos Totales",
    "formula": "(WOW / Totales) x 100",
    "impact": "% WOW: Nivel de atracción inicial"
  },

  "review": {
    "input_revised_1": "WOW Post",
    "input_revised_2": "Totales Post",
    "result_revised": "Impacto Mejorado"
  }
},
{
  "id": "CIR-S6",
  "name": "Estética Inconsistente",
  "specialty": "marca",
  "plan": "PRE",
  "domain": "estética",
  "description": "La estética visual cambia según quién la crea, generando una marca irregular y poco profesional.",

  "kpi": {
    "question": "¿Tu marca tiene un estilo reconocible o depende de quién diseñe?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Homogeneización estética",
    "decision_explanation": "Unificar criterios visuales",
    "action": "Crear sistema visual modular",
    "action_explanation": "Aumenta consistencia",
    "tool": "Sistema Visual MASESORA",
    "tool_explanation": "Define módulos visuales reutilizables",

    "objective": "Aumentar coherencia estética",
    "kpi_target": "Coherencia > 80%",
    "activation_condition": "Coherencia < 60%",
    "success_condition": "Estética uniforme en todos los soportes",
    "risk_if_ignored": "Marca amateur y poco confiable",
    "sequence": [
      "Auditar estética actual",
      "Definir módulos visuales",
      "Aplicar sistema en todos los soportes"
    ],
    "impact_level": "medio",
    "timeframe": "2 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno Estético",
    "master_decision_explanation": "Mantener estética sólida y reconocible",
    "master_action": "Revisión estética trimestral",
    "master_action_explanation": "Evita desviaciones visuales",
    "master_tool": "Radar Estético",
    "master_tool_explanation": "Monitoriza consistencia visual"
  },

  "inputs": {
    "input_a": "Piezas Coherentes",
    "input_b": "Piezas Totales",
    "formula": "(Coherentes / Totales) x 100",
    "impact": "% Coherencia Estética: Nivel de uniformidad visual"
  },

  "review": {
    "input_revised_1": "Coherentes Post",
    "input_revised_2": "Totales Post",
    "result_revised": "Estética Unificada"
  }
},
{
  "id": "CIR-S7",
  "name": "Materiales de Baja Calidad",
  "specialty": "marca",
  "plan": "PRE",
  "domain": "materiales",
  "description": "Los materiales visuales (PDF, presentaciones, catálogos, redes) se perciben baratos, pixelados o poco profesionales.",

  "kpi": {
    "question": "¿Tus materiales parecen premium o hechos con prisas?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Upgrade visual",
    "decision_explanation": "Elevar la calidad de todos los materiales",
    "action": "Rediseñar materiales clave en alta calidad",
    "action_explanation": "Aumenta percepción de valor",
    "tool": "Kit Premium de Materiales",
    "tool_explanation": "Define estándares de calidad visual",

    "objective": "Aumentar percepción premium",
    "kpi_target": "Calidad > 80%",
    "activation_condition": "Calidad < 60%",
    "success_condition": "Materiales profesionales y consistentes",
    "risk_if_ignored": "Sensación de marca barata",
    "sequence": [
      "Auditar materiales actuales",
      "Rediseñar piezas clave",
      "Aplicar estándares premium"
    ],
    "impact_level": "alto",
    "timeframe": "2 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Calidad Visual",
    "master_decision_explanation": "Mantener materiales premium",
    "master_action": "Optimizar estándares visuales",
    "master_action_explanation": "Evita caída de calidad",
    "master_tool": "Radar de Calidad Visual",
    "master_tool_explanation": "Monitoriza calidad de materiales"
  },

  "inputs": {
    "input_a": "Materiales Premium",
    "input_b": "Materiales Totales",
    "formula": "(Premium / Totales) x 100",
    "impact": "% Calidad: Nivel de profesionalidad visual"
  },

  "review": {
    "input_revised_1": "Premium Post",
    "input_revised_2": "Totales Post",
    "result_revised": "Calidad Elevada"
  }
},
{
  "id": "CIR-S8",
  "name": "Marca Sin Personalidad",
  "specialty": "marca",
  "plan": "PRE",
  "domain": "personalidad",
  "description": "La marca no transmite una identidad clara, diferenciada o memorable.",

  "kpi": {
    "question": "¿Tu marca tiene alma o solo colores bonitos?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Definición de personalidad",
    "decision_explanation": "Crear una identidad emocional clara",
    "action": "Diseñar arquetipo y tono de marca",
    "action_explanation": "Aumenta diferenciación",
    "tool": "Arquetipo de Marca MASESORA",
    "tool_explanation": "Define personalidad y tono",

    "objective": "Aumentar diferenciación",
    "kpi_target": "Diferenciación > 70%",
    "activation_condition": "Diferenciación < 50%",
    "success_condition": "Marca con personalidad clara",
    "risk_if_ignored": "Ser una marca más del montón",
    "sequence": [
      "Definir arquetipo",
      "Diseñar tono emocional",
      "Aplicar personalidad en todos los puntos"
    ],
    "impact_level": "medio",
    "timeframe": "3 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Personalidad",
    "master_decision_explanation": "Mantener identidad emocional sólida",
    "master_action": "Optimizar tono y narrativa",
    "master_action_explanation": "Evita pérdida de personalidad",
    "master_tool": "Radar de Personalidad",
    "master_tool_explanation": "Monitoriza fuerza emocional"
  },

  "inputs": {
    "input_a": "Elementos con Personalidad",
    "input_b": "Elementos Totales",
    "formula": "(Personales / Totales) x 100",
    "impact": "% Personalidad: Nivel de identidad emocional"
  },

  "review": {
    "input_revised_1": "Personales Post",
    "input_revised_2": "Totales Post",
    "result_revised": "Personalidad Definida"
  }
},
{
  "id": "CIR-S9",
  "name": "Marca Sin Diferenciación",
  "specialty": "marca",
  "plan": "PRE",
  "domain": "diferenciación",
  "description": "La marca no destaca frente a la competencia y se percibe como una opción más.",

  "kpi": {
    "question": "¿Tu marca destaca o se pierde entre las demás?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Posicionamiento quirúrgico",
    "decision_explanation": "Definir un espacio único en la mente del cliente",
    "action": "Crear propuesta de valor diferenciada",
    "action_explanation": "Aumenta ventaja competitiva",
    "tool": "Mapa de Posicionamiento",
    "tool_explanation": "Visualiza huecos competitivos",

    "objective": "Aumentar diferenciación",
    "kpi_target": "Diferenciación > 70%",
    "activation_condition": "Diferenciación < 50%",
    "success_condition": "Marca única y reconocible",
    "risk_if_ignored": "Competencia te sustituye fácilmente",
    "sequence": [
      "Analizar competencia",
      "Definir propuesta única",
      "Aplicar posicionamiento en la comunicación"
    ],
    "impact_level": "alto",
    "timeframe": "3 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Posicionamiento",
    "master_decision_explanation": "Mantener ventaja competitiva",
    "master_action": "Optimizar propuesta de valor",
    "master_action_explanation": "Evita ser copiable",
    "master_tool": "Radar de Posicionamiento",
    "master_tool_explanation": "Monitoriza diferenciación real"
  },

  "inputs": {
    "input_a": "Elementos Únicos",
    "input_b": "Elementos Totales",
    "formula": "(Únicos / Totales) x 100",
    "impact": "% Diferenciación: Nivel de unicidad de la marca"
  },

  "review": {
    "input_revised_1": "Únicos Post",
    "input_revised_2": "Totales Post",
    "result_revised": "Diferenciación Mejorada"
  }
},
{
  "id": "CIR-S10",
  "name": "Marca de Alto Impacto",
  "specialty": "marca",
  "plan": "PRE",
  "domain": "excelencia",
  "description": "Nivel 10: marca sólida, coherente, moderna y con un WOW inmediato en todos los puntos de contacto.",

  "kpi": {
    "question": "¿Tu marca genera un WOW inmediato y sostenido?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Certificación de marca",
    "decision_explanation": "Validar excelencia visual y comunicativa",
    "action": "Auditoría completa de identidad, coherencia y diferenciación",
    "action_explanation": "Garantiza excelencia total",
    "tool": "Certificado S10 Marca",
    "tool_explanation": "Evalúa impacto y coherencia",

    "objective": "Aumentar valor percibido",
    "kpi_target": "Impacto > 90%",
    "activation_condition": "Impacto < 80%",
    "success_condition": "Marca icónica y memorable",
    "risk_if_ignored": "Pérdida de competitividad visual",
    "sequence": [
      "Auditar marca completa",
      "Corregir desviaciones",
      "Certificar S10"
    ],
    "impact_level": "alto",
    "timeframe": "4 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Excelencia de Marca",
    "master_decision_explanation": "Convertir la marca en un activo estratégico",
    "master_action": "Optimizar impacto visual anual",
    "master_action_explanation": "Mantiene excelencia continua",
    "master_tool": "Radar S10 Marca",
    "master_tool_explanation": "Monitoriza excelencia visual"
  },

  "inputs": {
    "input_a": "Pilares de Marca",
    "input_b": "Pilares Cumplidos",
    "formula": "(Cumplidos / Pilares) x 100",
    "impact": "Índice S10 Marca: Nivel de excelencia visual y comunicativa"
  },

  "review": {
    "input_revised_1": "Pilares Post",
    "input_revised_2": "Cumplidos Post",
    "result_revised": "Excelencia Alcanzada"
  }
}
  ]
},
{
  "specialty": "organizacional",
  "symptoms": [
  {
  "id": "PSI-S1",
  "name": "Clima Emocional Tenso",
  "specialty": "organizacional",
  "plan": "PIE",
  "domain": "clima",
  "description": "El ambiente emocional del equipo está cargado, tenso o apagado, afectando la colaboración y el rendimiento.",

  "kpi": {
    "question": "¿Tu equipo respira o aguanta la respiración?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Descompresión emocional",
    "decision_explanation": "Liberar tensiones acumuladas",
    "action": "Sesión de escucha activa y regulación emocional",
    "action_explanation": "Reduce tensión y mejora el clima",
    "tool": "Protocolo de Higiene Emocional",
    "tool_explanation": "Guía para gestionar emociones en equipo",

    "objective": "Aumentar bienestar emocional",
    "kpi_target": "Clima > 75%",
    "activation_condition": "Clima < 55%",
    "success_condition": "Ambiente sano y colaborativo",
    "risk_if_ignored": "Conflictos, rotación y baja productividad",
    "sequence": [
      "Detectar tensiones",
      "Facilitar sesión emocional",
      "Establecer rituales de higiene emocional"
    ],
    "impact_level": "alto",
    "timeframe": "1 semana"
  },

  "master_treatment": {
    "master_decision": "Gobierno Emocional",
    "master_decision_explanation": "Mantener un clima sano y estable",
    "master_action": "Optimizar rituales emocionales",
    "master_action_explanation": "Evita acumulación de tensiones",
    "master_tool": "Radar Emocional",
    "master_tool_explanation": "Monitoriza el clima del equipo"
  },

  "inputs": {
    "input_a": "Tensiones Detectadas",
    "input_b": "Tensiones Resueltas",
    "formula": "(Resueltas / Detectadas) x 100",
    "impact": "% Resolución Emocional: Capacidad del equipo para gestionar tensiones"
  },

  "review": {
    "input_revised_1": "Detectadas Post",
    "input_revised_2": "Resueltas Post",
    "result_revised": "Clima Emocional Mejorado"
  }
},
{
  "id": "PSI-S2",
  "name": "Falta de Cohesión",
  "specialty": "organizacional",
  "plan": "PIE",
  "domain": "cohesión",
  "description": "El equipo funciona como individuos aislados en lugar de un sistema coordinado.",

  "kpi": {
    "question": "¿Tu equipo rema junto o cada uno va a su ritmo?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Activación de cohesión",
    "decision_explanation": "Crear vínculos y sincronía",
    "action": "Dinámica de cohesión y roles complementarios",
    "action_explanation": "Aumenta colaboración",
    "tool": "Mapa de Sinergias",
    "tool_explanation": "Identifica fortalezas complementarias",

    "objective": "Aumentar cohesión del equipo",
    "kpi_target": "Cohesión > 70%",
    "activation_condition": "Cohesión < 50%",
    "success_condition": "Equipo unido y coordinado",
    "risk_if_ignored": "Descoordinación y baja eficiencia",
    "sequence": [
      "Identificar desconexiones",
      "Aplicar dinámica de cohesión",
      "Revisar sinergias mensualmente"
    ],
    "impact_level": "medio",
    "timeframe": "2 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Cohesión",
    "master_decision_explanation": "Mantener equipo unido",
    "master_action": "Optimizar sinergias",
    "master_action_explanation": "Evita aislamiento",
    "master_tool": "Radar de Cohesión",
    "master_tool_explanation": "Monitoriza unión del equipo"
  },

  "inputs": {
    "input_a": "Sinergias Activas",
    "input_b": "Sinergias Potenciales",
    "formula": "(Activas / Potenciales) x 100",
    "impact": "% Sinergia: Nivel de colaboración real"
  },

  "review": {
    "input_revised_1": "Activas Post",
    "input_revised_2": "Potenciales Post",
    "result_revised": "Cohesión Mejorada"
  }
},
{
  "id": "PSI-S3",
  "name": "Comunicación Deficiente",
  "specialty": "organizacional",
  "plan": "PIE",
  "domain": "comunicación",
  "description": "La información no fluye, se malinterpreta o llega tarde, generando errores y frustración.",

  "kpi": {
    "question": "¿Tu equipo se entiende o se interpreta?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Rehabilitación comunicativa",
    "decision_explanation": "Mejorar claridad y canales",
    "action": "Implementar protocolo de comunicación interna",
    "action_explanation": "Reduce errores y malentendidos",
    "tool": "Guía de Comunicación Consciente",
    "tool_explanation": "Define cómo comunicar y por qué canal",

    "objective": "Aumentar claridad comunicativa",
    "kpi_target": "Claridad > 75%",
    "activation_condition": "Claridad < 55%",
    "success_condition": "Comunicación clara y fluida",
    "risk_if_ignored": "Errores, duplicidades y frustración",
    "sequence": [
      "Auditar comunicación actual",
      "Definir protocolo",
      "Aplicar rituales de comunicación"
    ],
    "impact_level": "alto",
    "timeframe": "1-2 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Comunicación",
    "master_decision_explanation": "Mantener comunicación clara",
    "master_action": "Optimizar canales y rituales",
    "master_action_explanation": "Evita recaídas comunicativas",
    "master_tool": "Radar de Comunicación",
    "master_tool_explanation": "Monitoriza claridad real"
  },

  "inputs": {
    "input_a": "Mensajes Claros",
    "input_b": "Mensajes Totales",
    "formula": "(Claros / Totales) x 100",
    "impact": "% Claridad: Nivel de comunicación efectiva"
  },

  "review": {
    "input_revised_1": "Claros Post",
    "input_revised_2": "Totales Post",
    "result_revised": "Comunicación Mejorada"
  }
},
{
  "id": "PSI-S4",
  "name": "Liderazgo Emocional Débil",
  "specialty": "organizacional",
  "plan": "PRE",
  "domain": "liderazgo",
  "description": "El líder no gestiona emociones, tensiones ni motivación del equipo de forma efectiva.",

  "kpi": {
    "question": "¿Tu liderazgo calma o enciende incendios?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Entrenamiento emocional",
    "decision_explanation": "Desarrollar liderazgo consciente",
    "action": "Formación en inteligencia emocional aplicada",
    "action_explanation": "Aumenta capacidad de guía",
    "tool": "Modelo de Liderazgo Emocional",
    "tool_explanation": "Define habilidades emocionales clave",

    "objective": "Aumentar liderazgo emocional",
    "kpi_target": "Liderazgo > 70%",
    "activation_condition": "Liderazgo < 50%",
    "success_condition": "Líder que regula, guía y motiva",
    "risk_if_ignored": "Conflictos, tensión y baja moral",
    "sequence": [
      "Evaluar estilo emocional",
      "Aplicar formación",
      "Revisar impacto mensual"
    ],
    "impact_level": "alto",
    "timeframe": "3-4 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Liderazgo Emocional",
    "master_decision_explanation": "Mantener liderazgo sano",
    "master_action": "Optimizar habilidades emocionales",
    "master_action_explanation": "Evita liderazgo tóxico o ausente",
    "master_tool": "Radar de Liderazgo Emocional",
    "master_tool_explanation": "Monitoriza madurez emocional"
  },

  "inputs": {
    "input_a": "Situaciones Reguladas",
    "input_b": "Situaciones Totales",
    "formula": "(Reguladas / Totales) x 100",
    "impact": "% Regulación: Capacidad del líder para gestionar emociones"
  },

  "review": {
    "input_revised_1": "Reguladas Post",
    "input_revised_2": "Totales Post",
    "result_revised": "Liderazgo Emocional Mejorado"
  }
},
{
  "id": "PSI-S5",
  "name": "Cultura Fragmentada",
  "specialty": "organizacional",
  "plan": "PRE",
  "domain": "cultura",
  "description": "Los valores no están claros, no se viven o cada persona interpreta la cultura de forma distinta.",

  "kpi": {
    "question": "¿Tu cultura se vive o solo se menciona?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Reprogramación cultural",
    "decision_explanation": "Definir y activar valores reales",
    "action": "Crear código cultural observable",
    "action_explanation": "Aumenta coherencia",
    "tool": "Manual Cultural Vivo",
    "tool_explanation": "Traduce valores en comportamientos",

    "objective": "Aumentar coherencia cultural",
    "kpi_target": "Coherencia > 70%",
    "activation_condition": "Coherencia < 50%",
    "success_condition": "Cultura clara, viva y coherente",
    "risk_if_ignored": "Incoherencia, conflictos y pérdida de identidad",
    "sequence": [
      "Definir valores reales",
      "Traducirlos a comportamientos",
      "Revisar coherencia mensual"
    ],
    "impact_level": "medio",
    "timeframe": "3 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno Cultural",
    "master_decision_explanation": "Mantener cultura sólida",
    "master_action": "Optimizar rituales culturales",
    "master_action_explanation": "Evita fragmentación",
    "master_tool": "Radar Cultural",
    "master_tool_explanation": "Monitoriza coherencia real"
  },

  "inputs": {
    "input_a": "Comportamientos Coherentes",
    "input_b": "Comportamientos Totales",
    "formula": "(Coherentes / Totales) x 100",
    "impact": "% Coherencia Cultural: Nivel de cultura viva"
  },

  "review": {
    "input_revised_1": "Coherentes Post",
    "input_revised_2": "Totales Post",
    "result_revised": "Cultura Reforzada"
  }
},
{
  "id": "PSI-S6",
  "name": "Desalineación DISC",
  "specialty": "organizacional",
  "plan": "PRE",
  "domain": "perfiles",
  "description": "Los roles y tareas no están alineados con los perfiles DISC del equipo, generando estrés, fricción y bajo rendimiento.",

  "kpi": {
    "question": "¿Tu equipo trabaja desde su fortaleza o desde su agotamiento?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Alineación de perfiles",
    "decision_explanation": "Asignar tareas según fortalezas DISC",
    "action": "Mapear perfiles y reasignar responsabilidades",
    "action_explanation": "Aumenta rendimiento y bienestar",
    "tool": "Mapa DISC Operativo",
    "tool_explanation": "Conecta perfiles con tareas",

    "objective": "Aumentar rendimiento natural",
    "kpi_target": "Alineación > 75%",
    "activation_condition": "Alineación < 55%",
    "success_condition": "Personas trabajando desde su fortaleza",
    "risk_if_ignored": "Estrés, errores y desgaste emocional",
    "sequence": [
      "Evaluar perfiles DISC",
      "Mapear tareas por fortaleza",
      "Reasignar responsabilidades"
    ],
    "impact_level": "alto",
    "timeframe": "3 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Perfiles",
    "master_decision_explanation": "Mantener roles alineados a fortalezas",
    "master_action": "Optimizar asignación de tareas",
    "master_action_explanation": "Evita desalineación futura",
    "master_tool": "Radar DISC",
    "master_tool_explanation": "Monitoriza alineación de perfiles"
  },

  "inputs": {
    "input_a": "Tareas Alineadas",
    "input_b": "Tareas Totales",
    "formula": "(Alineadas / Totales) x 100",
    "impact": "% Alineación DISC: Nivel de trabajo desde fortalezas"
  },

  "review": {
    "input_revised_1": "Alineadas Post",
    "input_revised_2": "Totales Post",
    "result_revised": "Alineación Mejorada"
  }
},
{
  "id": "PSI-S7",
  "name": "Falta de Seguridad Psicológica",
  "specialty": "organizacional",
  "plan": "PRE",
  "domain": "seguridad",
  "description": "El equipo no se siente seguro para expresar ideas, errores o preocupaciones sin miedo a consecuencias.",

  "kpi": {
    "question": "¿Tu equipo habla sin miedo o se autocensura?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Creación de espacio seguro",
    "decision_explanation": "Fomentar apertura y confianza",
    "action": "Implementar ritual de conversación segura",
    "action_explanation": "Aumenta participación y creatividad",
    "tool": "Protocolo de Seguridad Psicológica",
    "tool_explanation": "Define reglas de interacción segura",

    "objective": "Aumentar confianza interna",
    "kpi_target": "Seguridad > 70%",
    "activation_condition": "Seguridad < 50%",
    "success_condition": "Equipo que habla sin miedo",
    "risk_if_ignored": "Ideas perdidas, errores ocultos y baja innovación",
    "sequence": [
      "Detectar barreras de seguridad",
      "Aplicar ritual de conversación segura",
      "Revisar participación mensual"
    ],
    "impact_level": "alto",
    "timeframe": "4 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Seguridad Psicológica",
    "master_decision_explanation": "Mantener un entorno seguro",
    "master_action": "Optimizar dinámicas de confianza",
    "master_action_explanation": "Evita silencios peligrosos",
    "master_tool": "Radar de Seguridad Psicológica",
    "master_tool_explanation": "Monitoriza apertura del equipo"
  },

  "inputs": {
    "input_a": "Participaciones Seguras",
    "input_b": "Participaciones Totales",
    "formula": "(Seguras / Totales) x 100",
    "impact": "% Seguridad: Nivel de apertura emocional"
  },

  "review": {
    "input_revised_1": "Seguras Post",
    "input_revised_2": "Totales Post",
    "result_revised": "Seguridad Mejorada"
  }
},
{
  "id": "PSI-S8",
  "name": "Motivación Irregular",
  "specialty": "organizacional",
  "plan": "PRE",
  "domain": "motivación",
  "description": "La motivación del equipo fluctúa sin patrón claro, afectando la constancia y el rendimiento.",

  "kpi": {
    "question": "¿Tu equipo mantiene la energía o vive en montaña rusa emocional?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Estabilización motivacional",
    "decision_explanation": "Crear un sistema de motivación constante",
    "action": "Implementar ritual de reconocimiento semanal",
    "action_explanation": "Aumenta energía sostenida",
    "tool": "Sistema de Motivación Continua",
    "tool_explanation": "Define rituales y recompensas",

    "objective": "Aumentar estabilidad emocional",
    "kpi_target": "Motivación > 75%",
    "activation_condition": "Motivación < 55%",
    "success_condition": "Energía estable y predecible",
    "risk_if_ignored": "Baja constancia y rendimiento irregular",
    "sequence": [
      "Detectar fluctuaciones",
      "Aplicar ritual de reconocimiento",
      "Revisar motivación semanal"
    ],
    "impact_level": "medio",
    "timeframe": "3 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno Motivacional",
    "master_decision_explanation": "Mantener energía estable",
    "master_action": "Optimizar sistema de reconocimiento",
    "master_action_explanation": "Evita bajones motivacionales",
    "master_tool": "Radar de Motivación",
    "master_tool_explanation": "Monitoriza energía del equipo"
  },

  "inputs": {
    "input_a": "Semanas Estables",
    "input_b": "Semanas Totales",
    "formula": "(Estables / Totales) x 100",
    "impact": "% Estabilidad: Nivel de constancia emocional"
  },

  "review": {
    "input_revised_1": "Estables Post",
    "input_revised_2": "Totales Post",
    "result_revised": "Motivación Estabilizada"
  }
},
{
  "id": "PSI-S9",
  "name": "Falta de Autoconciencia",
  "specialty": "organizacional",
  "plan": "PRE",
  "domain": "autoconciencia",
  "description": "Las personas no identifican sus propios patrones emocionales, fortalezas o áreas de mejora.",

  "kpi": {
    "question": "¿Tu equipo se conoce o solo reacciona?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Despertar de autoconciencia",
    "decision_explanation": "Aumentar comprensión personal",
    "action": "Sesión de autoconocimiento guiado",
    "action_explanation": "Aumenta madurez emocional",
    "tool": "Cuaderno de Autoconciencia",
    "tool_explanation": "Guía para identificar patrones personales",

    "objective": "Aumentar madurez emocional",
    "kpi_target": "Autoconciencia > 70%",
    "activation_condition": "Autoconciencia < 50%",
    "success_condition": "Personas que se conocen y regulan",
    "risk_if_ignored": "Reacciones impulsivas y conflictos",
    "sequence": [
      "Evaluar nivel de autoconciencia",
      "Aplicar sesión guiada",
      "Revisar patrones mensualmente"
    ],
    "impact_level": "medio",
    "timeframe": "4 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Autoconciencia",
    "master_decision_explanation": "Mantener madurez emocional",
    "master_action": "Optimizar rituales de autoconocimiento",
    "master_action_explanation": "Evita reactividad emocional",
    "master_tool": "Radar de Autoconciencia",
    "master_tool_explanation": "Monitoriza madurez personal"
  },

  "inputs": {
    "input_a": "Patrones Identificados",
    "input_b": "Patrones Totales",
    "formula": "(Identificados / Totales) x 100",
    "impact": "% Autoconciencia: Nivel de comprensión personal"
  },

  "review": {
    "input_revised_1": "Identificados Post",
    "input_revised_2": "Totales Post",
    "result_revised": "Autoconciencia Mejorada"
  }
},
{
  "id": "PSI-S10",
  "name": "Salud Organizacional",
  "specialty": "organizacional",
  "plan": "PRE",
  "domain": "excelencia",
  "description": "Nivel 10: cultura sólida, liderazgo maduro, comunicación clara y equipo emocionalmente sano y cohesionado.",

  "kpi": {
    "question": "¿Tu organización funciona como un organismo sano y consciente?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Certificación organizacional",
    "decision_explanation": "Validar salud emocional y cultural",
    "action": "Auditoría completa de cultura, liderazgo y clima",
    "action_explanation": "Garantiza excelencia organizacional",
    "tool": "Certificado S10 Organizacional",
    "tool_explanation": "Evalúa salud emocional y cultural",

    "objective": "Aumentar madurez organizacional",
    "kpi_target": "Índice S10 > 90%",
    "activation_condition": "Índice < 80%",
    "success_condition": "Organización sana, estable y consciente",
    "risk_if_ignored": "Desgaste emocional y pérdida de talento",
    "sequence": [
      "Auditar salud organizacional",
      "Corregir desviaciones",
      "Certificar S10"
    ],
    "impact_level": "alto",
    "timeframe": "4 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Excelencia Organizacional",
    "master_decision_explanation": "Mantener salud emocional y cultural",
    "master_action": "Optimizar cultura y liderazgo",
    "master_action_explanation": "Evita deterioro organizacional",
    "master_tool": "Radar S10 Organizacional",
    "master_tool_explanation": "Monitoriza excelencia emocional y cultural"
  },

  "inputs": {
    "input_a": "Pilares Organizacionales",
    "input_b": "Pilares Cumplidos",
    "formula": "(Cumplidos / Pilares) x 100",
    "impact": "Índice S10 Organizacional: Nivel de salud emocional y cultural"
  },

  "review": {
    "input_revised_1": "Pilares Post",
    "input_revised_2": "Cumplidos Post",
    "result_revised": "Excelencia Organizacional Alcanzada"
  }
}
  ]
},
{
  "specialty": "personas",
  "symptoms": [
  {

  "id": "RES-S1",
  "name": "Crecimiento Desordenado",
  "specialty": "personas",
  "plan": "PIE",
  "domain": "estructura",
  "description": "La empresa crece en ventas o tamaño, pero sin estructura clara, generando caos y sobrecarga.",

  "kpi": {
    "question": "¿Tu crecimiento te fortalece o te rompe por dentro?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Estructuración urgente",
    "decision_explanation": "Crear orden antes de seguir creciendo",
    "action": "Definir estructura mínima viable",
    "action_explanation": "Evita colapsos operativos",
    "tool": "Mapa de Estructura Sostenible",
    "tool_explanation": "Define roles, flujos y límites",

    "objective": "Aumentar estabilidad del crecimiento",
    "kpi_target": "Estabilidad > 70%",
    "activation_condition": "Estabilidad < 50%",
    "success_condition": "Crecimiento ordenado y sostenible",
    "risk_if_ignored": "Caos, errores y desgaste del equipo",
    "sequence": [
      "Auditar estructura actual",
      "Definir estructura mínima viable",
      "Asignar roles y límites"
    ],
    "impact_level": "alto",
    "timeframe": "1-2 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Crecimiento",
    "master_decision_explanation": "Mantener crecimiento sano",
    "master_action": "Optimizar estructura trimestralmente",
    "master_action_explanation": "Evita crecimiento enfermo",
    "master_tool": "Radar de Crecimiento Sano",
    "master_tool_explanation": "Monitoriza estabilidad estructural"
  },

  "inputs": {
    "input_a": "Procesos Estables",
    "input_b": "Procesos Totales",
    "formula": "(Estables / Totales) x 100",
    "impact": "% Estabilidad: Nivel de crecimiento sano"
  },

  "review": {
    "input_revised_1": "Estables Post",
    "input_revised_2": "Totales Post",
    "result_revised": "Crecimiento Ordenado"
  }
},
{
  "id": "RES-S2",
  "name": "Sobrecarga del Equipo",
  "specialty": "personas",
  "plan": "PIE",
  "domain": "carga",
  "description": "El equipo está saturado, asumiendo más tareas de las que puede gestionar sin perder calidad.",

  "kpi": {
    "question": "¿Tu equipo trabaja o sobrevive cada semana?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Redistribución de carga",
    "decision_explanation": "Equilibrar tareas y responsabilidades",
    "action": "Auditar carga por rol",
    "action_explanation": "Evita agotamiento",
    "tool": "Mapa de Carga Operativa",
    "tool_explanation": "Visualiza saturación por persona",

    "objective": "Aumentar bienestar y rendimiento",
    "kpi_target": "Carga equilibrada > 70%",
    "activation_condition": "Carga equilibrada < 50%",
    "success_condition": "Equipo con carga sostenible",
    "risk_if_ignored": "Burnout, errores y rotación",
    "sequence": [
      "Auditar carga por persona",
      "Redistribuir tareas",
      "Revisar carga semanalmente"
    ],
    "impact_level": "alto",
    "timeframe": "1 semana"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Carga",
    "master_decision_explanation": "Mantener carga sostenible",
    "master_action": "Optimizar distribución de tareas",
    "master_action_explanation": "Evita saturación futura",
    "master_tool": "Radar de Carga",
    "master_tool_explanation": "Monitoriza saturación del equipo"
  },

  "inputs": {
    "input_a": "Tareas Sostenibles",
    "input_b": "Tareas Totales",
    "formula": "(Sostenibles / Totales) x 100",
    "impact": "% Sostenibilidad: Nivel de carga saludable"
  },

  "review": {
    "input_revised_1": "Sostenibles Post",
    "input_revised_2": "Totales Post",
    "result_revised": "Carga Equilibrada"
  }
},
{
  "id": "RES-S3",
  "name": "Incorporaciones Caóticas",
  "specialty": "personas",
  "plan": "PIE",
  "domain": "onboarding",
  "description": "Las nuevas incorporaciones entran sin guía, sin estructura y sin claridad, generando errores y frustración.",

  "kpi": {
    "question": "¿Tus nuevas personas aterrizan o se estrellan al entrar?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Onboarding estructurado",
    "decision_explanation": "Crear un aterrizaje seguro",
    "action": "Diseñar protocolo de incorporación",
    "action_explanation": "Reduce errores y acelera adaptación",
    "tool": "Kit de Onboarding Sano",
    "tool_explanation": "Define pasos, tiempos y responsables",

    "objective": "Aumentar adaptación inicial",
    "kpi_target": "Adaptación > 80%",
    "activation_condition": "Adaptación < 60%",
    "success_condition": "Incorporaciones fluidas y rápidas",
    "risk_if_ignored": "Errores, frustración y rotación temprana",
    "sequence": [
      "Definir pasos del onboarding",
      "Asignar responsables",
      "Revisar adaptación a los 30 días"
    ],
    "impact_level": "medio",
    "timeframe": "2 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Onboarding",
    "master_decision_explanation": "Mantener incorporaciones sanas",
    "master_action": "Optimizar protocolo de entrada",
    "master_action_explanation": "Evita caos en nuevas contrataciones",
    "master_tool": "Radar de Onboarding",
    "master_tool_explanation": "Monitoriza adaptación inicial"
  },

  "inputs": {
    "input_a": "Tareas Completadas",
    "input_b": "Tareas Onboarding",
    "formula": "(Completadas / Onboarding) x 100",
    "impact": "% Adaptación: Nivel de integración inicial"
  },

  "review": {
    "input_revised_1": "Completadas Post",
    "input_revised_2": "Onboarding Post",
    "result_revised": "Adaptación Mejorada"
  }
},
{
  "id": "RES-S4",
  "name": "Escalado Frágil",
  "specialty": "personas",
  "plan": "PRE",
  "domain": "escalabilidad",
  "description": "La empresa crece pero la estructura no soporta el ritmo, generando cuellos de botella y errores.",

  "kpi": {
    "question": "¿Tu empresa escala o se rompe al intentarlo?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Refuerzo estructural",
    "decision_explanation": "Fortalecer la base antes de crecer más",
    "action": "Definir roles, límites y procesos críticos",
    "action_explanation": "Aumenta capacidad de escala",
    "tool": "Blueprint de Escalabilidad",
    "tool_explanation": "Define estructura para crecer sin romperse",

    "objective": "Aumentar capacidad de escala",
    "kpi_target": "Escalabilidad > 70%",
    "activation_condition": "Escalabilidad < 50%",
    "success_condition": "Crecimiento estable y sin fricción",
    "risk_if_ignored": "Colapso operativo y desgaste del equipo",
    "sequence": [
      "Auditar puntos frágiles",
      "Reforzar procesos críticos",
      "Revisar capacidad de escala"
    ],
    "impact_level": "alto",
    "timeframe": "3 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Escalabilidad",
    "master_decision_explanation": "Mantener crecimiento sano",
    "master_action": "Optimizar estructura de escala",
    "master_action_explanation": "Evita fragilidad futura",
    "master_tool": "Radar de Escalabilidad",
    "master_tool_explanation": "Monitoriza capacidad de crecimiento"
  },

  "inputs": {
    "input_a": "Procesos Escalables",
    "input_b": "Procesos Totales",
    "formula": "(Escalables / Totales) x 100",
    "impact": "% Escalabilidad: Capacidad real de crecer sin romperse"
  },

  "review": {
    "input_revised_1": "Escalables Post",
    "input_revised_2": "Totales Post",
    "result_revised": "Escalabilidad Mejorada"
  }
},
{
  "id": "RES-S5",
  "name": "Cultura en Riesgo",
  "specialty": "personas",
  "plan": "PRE",
  "domain": "cultura",
  "description": "El crecimiento está debilitando la cultura: se pierden valores, hábitos y comportamientos clave.",

  "kpi": {
    "question": "¿Tu cultura crece contigo o se diluye al escalar?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Preservación cultural",
    "decision_explanation": "Proteger valores y comportamientos esenciales",
    "action": "Definir rituales culturales obligatorios",
    "action_explanation": "Aumenta coherencia",
    "tool": "Manual de Cultura Sostenible",
    "tool_explanation": "Define rituales y comportamientos clave",

    "objective": "Aumentar coherencia cultural",
    "kpi_target": "Coherencia > 75%",
    "activation_condition": "Coherencia < 55%",
    "success_condition": "Cultura fuerte y estable",
    "risk_if_ignored": "Pérdida de identidad y cohesión",
    "sequence": [
      "Definir valores esenciales",
      "Crear rituales culturales",
      "Revisar coherencia mensual"
    ],
    "impact_level": "medio",
    "timeframe": "3 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno Cultural",
    "master_decision_explanation": "Mantener cultura sólida al crecer",
    "master_action": "Optimizar rituales culturales",
    "master_action_explanation": "Evita dilución cultural",
    "master_tool": "Radar Cultural",
    "master_tool_explanation": "Monitoriza coherencia cultural"
  },

  "inputs": {
    "input_a": "Rituales Activos",
    "input_b": "Rituales Totales",
    "formula": "(Activos / Totales) x 100",
    "impact": "% Cultura Viva: Nivel de coherencia cultural"
  },

  "review": {
    "input_revised_1": "Activos Post",
    "input_revised_2": "Totales Post",
    "result_revised": "Cultura Reforzada"
  }
},
{
  "id": "RES-S6",
  "name": "Roles Saturados",
  "specialty": "personas",
  "plan": "PRE",
  "domain": "roles",
  "description": "Los roles han crecido más rápido que las personas, acumulando tareas que ya no son sostenibles ni coherentes.",

  "kpi": {
    "question": "¿Tus roles están definidos o son cajones de desastre?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Redefinición de roles",
    "decision_explanation": "Ajustar roles al crecimiento real",
    "action": "Reestructurar responsabilidades por nivel de valor",
    "action_explanation": "Reduce saturación y errores",
    "tool": "Ficha de Rol Sostenible",
    "tool_explanation": "Define tareas, límites y métricas",

    "objective": "Aumentar claridad y sostenibilidad",
    "kpi_target": "Claridad > 75%",
    "activation_condition": "Claridad < 55%",
    "success_condition": "Roles claros, sostenibles y equilibrados",
    "risk_if_ignored": "Burnout, errores y baja calidad",
    "sequence": [
      "Auditar tareas por rol",
      "Eliminar tareas impropias",
      "Redefinir responsabilidades"
    ],
    "impact_level": "alto",
    "timeframe": "3 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Roles",
    "master_decision_explanation": "Mantener roles sanos y actualizados",
    "master_action": "Optimizar estructura de roles trimestralmente",
    "master_action_explanation": "Evita saturación futura",
    "master_tool": "Radar de Roles",
    "master_tool_explanation": "Monitoriza claridad y carga"
  },

  "inputs": {
    "input_a": "Tareas Coherentes",
    "input_b": "Tareas Totales",
    "formula": "(Coherentes / Totales) x 100",
    "impact": "% Coherencia de Rol: Nivel de sostenibilidad del puesto"
  },

  "review": {
    "input_revised_1": "Coherentes Post",
    "input_revised_2": "Totales Post",
    "result_revised": "Roles Sostenibles"
  }
},
{
  "id": "RES-S7",
  "name": "Falta de Sucesión Interna",
  "specialty": "personas",
  "plan": "PRE",
  "domain": "sucesión",
  "description": "No existen personas preparadas para asumir roles clave si alguien se marcha o asciende.",

  "kpi": {
    "question": "Si mañana falta alguien clave, ¿tu empresa sigue o se detiene?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Plan de sucesión",
    "decision_explanation": "Preparar reemplazos internos",
    "action": "Identificar roles críticos y formar sucesores",
    "action_explanation": "Aumenta continuidad operativa",
    "tool": "Mapa de Sucesión",
    "tool_explanation": "Define suplentes y rutas de desarrollo",

    "objective": "Aumentar continuidad del negocio",
    "kpi_target": "Sucesión > 70%",
    "activation_condition": "Sucesión < 50%",
    "success_condition": "Roles críticos cubiertos",
    "risk_if_ignored": "Parálisis operativa ante bajas o salidas",
    "sequence": [
      "Identificar roles críticos",
      "Asignar sucesores",
      "Formar y evaluar progresos"
    ],
    "impact_level": "alto",
    "timeframe": "4 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Sucesión",
    "master_decision_explanation": "Mantener continuidad operativa",
    "master_action": "Optimizar rutas de sucesión",
    "master_action_explanation": "Evita vacíos críticos",
    "master_tool": "Radar de Sucesión",
    "master_tool_explanation": "Monitoriza preparación interna"
  },

  "inputs": {
    "input_a": "Roles con Sucesor",
    "input_b": "Roles Críticos",
    "formula": "(Sucesor / Críticos) x 100",
    "impact": "% Sucesión: Nivel de continuidad operativa"
  },

  "review": {
    "input_revised_1": "Sucesor Post",
    "input_revised_2": "Críticos Post",
    "result_revised": "Sucesión Asegurada"
  }
},
{
  "id": "RES-S8",
  "name": "Falta de Escalabilidad Humana",
  "specialty": "personas",
  "plan": "PRE",
  "domain": "escalabilidad",
  "description": "El equipo no puede asumir más volumen sin contratar más personas, lo que limita el crecimiento.",

  "kpi": {
    "question": "¿Tu equipo escala o necesita duplicarse para crecer?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Optimización de capacidad",
    "decision_explanation": "Aumentar escalabilidad sin aumentar plantilla",
    "action": "Rediseñar flujos y eliminar tareas de bajo valor",
    "action_explanation": "Aumenta capacidad real",
    "tool": "Mapa de Capacidad Humana",
    "tool_explanation": "Identifica cuellos de carga humana",

    "objective": "Aumentar capacidad de escala",
    "kpi_target": "Escalabilidad > 70%",
    "activation_condition": "Escalabilidad < 50%",
    "success_condition": "Equipo capaz de asumir más volumen",
    "risk_if_ignored": "Crecimiento limitado y costes crecientes",
    "sequence": [
      "Auditar carga humana",
      "Eliminar tareas de bajo valor",
      "Optimizar flujos de trabajo"
    ],
    "impact_level": "alto",
    "timeframe": "3 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Capacidad",
    "master_decision_explanation": "Mantener escalabilidad humana",
    "master_action": "Optimizar flujos y automatizaciones",
    "master_action_explanation": "Evita saturación futura",
    "master_tool": "Radar de Capacidad",
    "master_tool_explanation": "Monitoriza escalabilidad real"
  },

  "inputs": {
    "input_a": "Tareas de Alto Valor",
    "input_b": "Tareas Totales",
    "formula": "(AltoValor / Totales) x 100",
    "impact": "% Capacidad: Nivel de escalabilidad humana"
  },

  "review": {
    "input_revised_1": "AltoValor Post",
    "input_revised_2": "Totales Post",
    "result_revised": "Escalabilidad Aumentada"
  }
},
{
  "id": "RES-S9",
  "name": "Desgaste Cultural",
  "specialty": "personas",
  "plan": "PRE",
  "domain": "cultura",
  "description": "El crecimiento está erosionando los valores, hábitos y comportamientos que antes definían a la empresa.",

  "kpi": {
    "question": "¿Tu cultura se fortalece o se desgasta con el crecimiento?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Reforzamiento cultural",
    "decision_explanation": "Proteger y revitalizar la cultura",
    "action": "Redefinir comportamientos esenciales",
    "action_explanation": "Aumenta coherencia",
    "tool": "Código Cultural Sostenible",
    "tool_explanation": "Define comportamientos y rituales clave",

    "objective": "Aumentar coherencia cultural",
    "kpi_target": "Coherencia > 75%",
    "activation_condition": "Coherencia < 55%",
    "success_condition": "Cultura fuerte y estable",
    "risk_if_ignored": "Pérdida de identidad y cohesión",
    "sequence": [
      "Auditar cultura actual",
      "Redefinir comportamientos esenciales",
      "Aplicar rituales culturales"
    ],
    "impact_level": "medio",
    "timeframe": "3 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno Cultural",
    "master_decision_explanation": "Mantener cultura sólida al crecer",
    "master_action": "Optimizar rituales culturales",
    "master_action_explanation": "Evita desgaste futuro",
    "master_tool": "Radar Cultural",
    "master_tool_explanation": "Monitoriza coherencia cultural"
  },

  "inputs": {
    "input_a": "Comportamientos Coherentes",
    "input_b": "Comportamientos Totales",
    "formula": "(Coherentes / Totales) x 100",
    "impact": "% Cultura Viva: Nivel de coherencia cultural"
  },

  "review": {
    "input_revised_1": "Coherentes Post",
    "input_revised_2": "Totales Post",
    "result_revised": "Cultura Reforzada"
  }
},
{
  "id": "RES-S10",
  "name": "Crecimiento Sano",
  "specialty": "personas",
  "plan": "PRE",
  "domain": "excelencia",
  "description": "Nivel 10: crecimiento estable, sostenible, con estructura sólida, cultura fuerte y roles equilibrados.",

  "kpi": {
    "question": "¿Tu empresa crece como un organismo sano y estructurado?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Certificación de crecimiento sano",
    "decision_explanation": "Validar estructura, cultura y escalabilidad",
    "action": "Auditoría completa de crecimiento y estructura",
    "action_explanation": "Garantiza crecimiento sostenible",
    "tool": "Certificado S10 Crecimiento",
    "tool_explanation": "Evalúa salud estructural y cultural",

    "objective": "Aumentar madurez de crecimiento",
    "kpi_target": "Índice S10 > 90%",
    "activation_condition": "Índice < 80%",
    "success_condition": "Crecimiento sano, estable y sostenible",
    "risk_if_ignored": "Crecimiento enfermo y colapsos operativos",
    "sequence": [
      "Auditar crecimiento",
      "Corregir desviaciones",
      "Certificar S10"
    ],
    "impact_level": "alto",
    "timeframe": "4 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Excelencia en Crecimiento",
    "master_decision_explanation": "Mantener crecimiento sano a largo plazo",
    "master_action": "Optimizar estructura y cultura",
    "master_action_explanation": "Evita recaídas",
    "master_tool": "Radar S10 Crecimiento",
    "master_tool_explanation": "Monitoriza excelencia estructural"
  },

  "inputs": {
    "input_a": "Pilares de Crecimiento",
    "input_b": "Pilares Cumplidos",
    "formula": "(Cumplidos / Pilares) x 100",
    "impact": "Índice S10 Crecimiento: Nivel de salud estructural y cultural"
  },

  "review": {
    "input_revised_1": "Pilares Post",
    "input_revised_2": "Cumplidos Post",
    "result_revised": "Crecimiento Sano Alcanzado"
  }
}
  ]
},
{
  "specialty": "experiencia",
  "symptoms":[
   {

  "id": "TER-S1",
  "name": "Experiencia Irregular",
  "specialty": "experiencia",
  "plan": "PIE",
  "domain": "consistencia",
  "description": "La experiencia del cliente varía según el día, la persona o el canal, generando percepciones inconsistentes.",

  "kpi": {
    "question": "¿Tu experiencia es consistente o depende de la suerte del cliente?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Estandarización de experiencia",
    "decision_explanation": "Crear una experiencia estable y repetible",
    "action": "Definir protocolo de experiencia mínima viable",
    "action_explanation": "Aumenta consistencia y satisfacción",
    "tool": "Mapa de Experiencia Mínima",
    "tool_explanation": "Define pasos obligatorios en cada interacción",

    "objective": "Aumentar consistencia",
    "kpi_target": "Consistencia > 75%",
    "activation_condition": "Consistencia < 55%",
    "success_condition": "Experiencia estable en todos los canales",
    "risk_if_ignored": "Clientes confundidos y pérdida de confianza",
    "sequence": [
      "Auditar experiencia actual",
      "Definir pasos mínimos",
      "Aplicar protocolo en todos los canales"
    ],
    "impact_level": "alto",
    "timeframe": "1-2 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Experiencia",
    "master_decision_explanation": "Mantener experiencia estable",
    "master_action": "Optimizar protocolo trimestralmente",
    "master_action_explanation": "Evita variaciones futuras",
    "master_tool": "Radar de Consistencia",
    "master_tool_explanation": "Monitoriza estabilidad de experiencia"
  },

  "inputs": {
    "input_a": "Interacciones Consistentes",
    "input_b": "Interacciones Totales",
    "formula": "(Consistentes / Totales) x 100",
    "impact": "% Consistencia: Nivel de estabilidad de la experiencia"
  },

  "review": {
    "input_revised_1": "Consistentes Post",
    "input_revised_2": "Totales Post",
    "result_revised": "Experiencia Estabilizada"
  }
},
{
  "id": "TER-S2",
  "name": "Baja Percepción de Valor",
  "specialty": "experiencia",
  "plan": "PIE",
  "domain": "valor",
  "description": "El cliente no percibe el valor real del servicio, generando dudas, comparaciones y resistencia al precio.",

  "kpi": {
    "question": "¿Tu cliente entiende tu valor o solo tu precio?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Refuerzo de valor",
    "decision_explanation": "Hacer visible el valor real",
    "action": "Rediseñar narrativa de valor",
    "action_explanation": "Aumenta percepción y confianza",
    "tool": "Guía de Valor Percibido",
    "tool_explanation": "Define mensajes clave de valor",

    "objective": "Aumentar percepción de valor",
    "kpi_target": "Valor > 75%",
    "activation_condition": "Valor < 55%",
    "success_condition": "Cliente que entiende y valora la oferta",
    "risk_if_ignored": "Comparación por precio y pérdida de ventas",
    "sequence": [
      "Auditar narrativa actual",
      "Redefinir mensajes de valor",
      "Aplicar narrativa en todos los puntos"
    ],
    "impact_level": "alto",
    "timeframe": "1 semana"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Valor",
    "master_decision_explanation": "Mantener percepción alta",
    "master_action": "Optimizar narrativa de valor",
    "master_action_explanation": "Evita pérdida de percepción",
    "master_tool": "Radar de Valor",
    "master_tool_explanation": "Monitoriza percepción real"
  },

  "inputs": {
    "input_a": "Mensajes de Valor Claros",
    "input_b": "Mensajes Totales",
    "formula": "(Claros / Totales) x 100",
    "impact": "% Claridad de Valor: Nivel de comprensión del cliente"
  },

  "review": {
    "input_revised_1": "Claros Post",
    "input_revised_2": "Totales Post",
    "result_revised": "Valor Percibido Mejorado"
  }
},
{
  "id": "TER-S3",
  "name": "Experiencia Fragmentada por Canales",
  "specialty": "experiencia",
  "plan": "PIE",
  "domain": "multicanalidad",
  "description": "El cliente recibe experiencias distintas según el canal: web, WhatsApp, presencial, redes o email.",

  "kpi": {
    "question": "¿Tu experiencia es omnicanal o un rompecabezas?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Unificación multicanal",
    "decision_explanation": "Crear una experiencia coherente en todos los canales",
    "action": "Definir guion unificado de interacción",
    "action_explanation": "Aumenta coherencia y confianza",
    "tool": "Guion Omnicanal",
    "tool_explanation": "Define mensajes y pasos por canal",

    "objective": "Aumentar coherencia omnicanal",
    "kpi_target": "Coherencia > 75%",
    "activation_condition": "Coherencia < 55%",
    "success_condition": "Experiencia igual en todos los canales",
    "risk_if_ignored": "Confusión, errores y pérdida de confianza",
    "sequence": [
      "Auditar canales actuales",
      "Definir guion unificado",
      "Aplicar coherencia en todos los puntos"
    ],
    "impact_level": "medio",
    "timeframe": "2 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno Omnicanal",
    "master_decision_explanation": "Mantener coherencia multicanal",
    "master_action": "Optimizar guion omnicanal",
    "master_action_explanation": "Evita fragmentación futura",
    "master_tool": "Radar Omnicanal",
    "master_tool_explanation": "Monitoriza coherencia por canal"
  },

  "inputs": {
    "input_a": "Canales Coherentes",
    "input_b": "Canales Totales",
    "formula": "(Coherentes / Totales) x 100",
    "impact": "% Coherencia Omnicanal: Nivel de experiencia unificada"
  },

  "review": {
    "input_revised_1": "Coherentes Post",
    "input_revised_2": "Totales Post",
    "result_revised": "Omnicanalidad Mejorada"
  }
},
{
  "id": "TER-S4",
  "name": "Reputación Débil",
  "specialty": "experiencia",
  "plan": "PRE",
  "domain": "reputación",
  "description": "La empresa no proyecta autoridad, confianza ni prestigio en su sector o comunidad.",

  "kpi": {
    "question": "¿Tu reputación te abre puertas o te las cierra?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Refuerzo reputacional",
    "decision_explanation": "Aumentar autoridad y confianza externa",
    "action": "Diseñar estrategia de reputación activa",
    "action_explanation": "Aumenta prestigio y atracción",
    "tool": "Plan de Reputación 360",
    "tool_explanation": "Define acciones de autoridad y visibilidad",

    "objective": "Aumentar reputación",
    "kpi_target": "Reputación > 75%",
    "activation_condition": "Reputación < 55%",
    "success_condition": "Marca respetada y reconocida",
    "risk_if_ignored": "Desconfianza y baja atracción",
    "sequence": [
      "Auditar reputación actual",
      "Definir acciones de autoridad",
      "Aplicar estrategia 360"
    ],
    "impact_level": "alto",
    "timeframe": "3 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Reputación",
    "master_decision_explanation": "Mantener prestigio sostenido",
    "master_action": "Optimizar acciones de autoridad",
    "master_action_explanation": "Evita caída reputacional",
    "master_tool": "Radar de Reputación",
    "master_tool_explanation": "Monitoriza prestigio real"
  },

  "inputs": {
    "input_a": "Acciones de Autoridad",
    "input_b": "Acciones Totales",
    "formula": "(Autoridad / Totales) x 100",
    "impact": "% Autoridad: Nivel de prestigio proyectado"
  },

  "review": {
    "input_revised_1": "Autoridad Post",
    "input_revised_2": "Totales Post",
    "result_revised": "Reputación Mejorada"
  }
},
{
  "id": "TER-S5",
  "name": "Digitalización Inútil",
  "specialty": "experiencia",
  "plan": "PRE",
  "domain": "digitalización",
  "description": "La empresa ha implementado herramientas digitales que no aportan valor real y complican la experiencia del cliente.",

  "kpi": {
    "question": "¿Tu digitalización ayuda o estorba al cliente?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Depuración digital",
    "decision_explanation": "Eliminar herramientas que no aportan valor",
    "action": "Auditar herramientas y flujos digitales",
    "action_explanation": "Simplifica la experiencia",
    "tool": "Mapa de Digitalización Útil",
    "tool_explanation": "Clasifica herramientas por valor real",

    "objective": "Aumentar utilidad digital",
    "kpi_target": "Utilidad > 75%",
    "activation_condition": "Utilidad < 55%",
    "success_condition": "Digitalización simple, útil y fluida",
    "risk_if_ignored": "Experiencia complicada y frustrante",
    "sequence": [
      "Auditar herramientas",
      "Eliminar lo inútil",
      "Optimizar lo que aporta valor"
    ],
    "impact_level": "medio",
    "timeframe": "2 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno Digital",
    "master_decision_explanation": "Mantener digitalización útil",
    "master_action": "Optimizar ecosistema digital",
    "master_action_explanation": "Evita complejidad innecesaria",
    "master_tool": "Radar Digital",
    "master_tool_explanation": "Monitoriza utilidad real"
  },

  "inputs": {
    "input_a": "Herramientas Útiles",
    "input_b": "Herramientas Totales",
    "formula": "(Útiles / Totales) x 100",
    "impact": "% Utilidad Digital: Nivel de aporte real al cliente"
  },

  "review": {
    "input_revised_1": "Útiles Post",
    "input_revised_2": "Totales Post",
    "result_revised": "Digitalización Optimizada"
  }
},
{
  "id": "TER-S6",
  "name": "Cliente Desorientado",
  "specialty": "experiencia",
  "plan": "PRE",
  "domain": "claridad",
  "description": "El cliente no entiende claramente qué hacer, cómo avanzar o cómo funciona el servicio, generando fricción y abandono.",

  "kpi": {
    "question": "¿Tu cliente avanza con claridad o se pierde en el camino?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Clarificación del recorrido",
    "decision_explanation": "Eliminar dudas y pasos confusos",
    "action": "Diseñar mapa de recorrido del cliente",
    "action_explanation": "Aumenta claridad y reduce fricción",
    "tool": "Customer Journey Simplificado",
    "tool_explanation": "Define pasos claros y visuales",

    "objective": "Aumentar claridad del proceso",
    "kpi_target": "Claridad > 75%",
    "activation_condition": "Claridad < 55%",
    "success_condition": "Cliente que avanza sin dudas",
    "risk_if_ignored": "Abandono, frustración y pérdida de ventas",
    "sequence": [
      "Auditar recorrido actual",
      "Eliminar pasos confusos",
      "Diseñar recorrido claro y visual"
    ],
    "impact_level": "alto",
    "timeframe": "2 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Claridad",
    "master_decision_explanation": "Mantener procesos claros",
    "master_action": "Optimizar recorrido del cliente",
    "master_action_explanation": "Evita confusión futura",
    "master_tool": "Radar de Claridad",
    "master_tool_explanation": "Monitoriza comprensión del cliente"
  },

  "inputs": {
    "input_a": "Pasos Claros",
    "input_b": "Pasos Totales",
    "formula": "(Claros / Totales) x 100",
    "impact": "% Claridad: Nivel de comprensión del proceso"
  },

  "review": {
    "input_revised_1": "Claros Post",
    "input_revised_2": "Totales Post",
    "result_revised": "Claridad Mejorada"
  }
},
{
  "id": "TER-S7",
  "name": "Baja Fidelización",
  "specialty": "experiencia",
  "plan": "PRE",
  "domain": "fidelización",
  "description": "Los clientes no repiten, no recomiendan y no desarrollan relación a largo plazo con la empresa.",

  "kpi": {
    "question": "¿Tus clientes vuelven porque quieren o porque no tienen alternativa?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Activación de fidelización",
    "decision_explanation": "Crear relación a largo plazo",
    "action": "Diseñar programa de fidelización emocional",
    "action_explanation": "Aumenta recurrencia",
    "tool": "Plan de Fidelización 3C",
    "tool_explanation": "Conexión, Cuidado y Continuidad",

    "objective": "Aumentar recurrencia",
    "kpi_target": "Fidelización > 70%",
    "activation_condition": "Fidelización < 50%",
    "success_condition": "Clientes que repiten y recomiendan",
    "risk_if_ignored": "Pérdida de ingresos recurrentes",
    "sequence": [
      "Analizar motivos de abandono",
      "Diseñar programa de fidelización",
      "Aplicar acciones de seguimiento"
    ],
    "impact_level": "alto",
    "timeframe": "3 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Fidelización",
    "master_decision_explanation": "Mantener clientes a largo plazo",
    "master_action": "Optimizar programa de fidelización",
    "master_action_explanation": "Evita pérdida de recurrencia",
    "master_tool": "Radar de Fidelización",
    "master_tool_explanation": "Monitoriza recurrencia real"
  },

  "inputs": {
    "input_a": "Clientes Recurrentes",
    "input_b": "Clientes Totales",
    "formula": "(Recurrentes / Totales) x 100",
    "impact": "% Recurrencia: Nivel de fidelización real"
  },

  "review": {
    "input_revised_1": "Recurrentes Post",
    "input_revised_2": "Totales Post",
    "result_revised": "Fidelización Mejorada"
  }
},
{
  "id": "TER-S8",
  "name": "Experiencia Lenta",
  "specialty": "experiencia",
  "plan": "PRE",
  "domain": "velocidad",
  "description": "El cliente percibe tiempos de espera largos, procesos lentos o respuestas tardías.",

  "kpi": {
    "question": "¿Tu experiencia fluye o desespera al cliente?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Aceleración de experiencia",
    "decision_explanation": "Reducir tiempos y fricciones",
    "action": "Optimizar tiempos de respuesta y procesos clave",
    "action_explanation": "Aumenta satisfacción",
    "tool": "Mapa de Velocidad del Cliente",
    "tool_explanation": "Identifica cuellos de botella temporales",

    "objective": "Aumentar velocidad de experiencia",
    "kpi_target": "Velocidad > 75%",
    "activation_condition": "Velocidad < 55%",
    "success_condition": "Experiencia rápida y fluida",
    "risk_if_ignored": "Abandono y frustración del cliente",
    "sequence": [
      "Auditar tiempos actuales",
      "Eliminar esperas innecesarias",
      "Optimizar procesos lentos"
    ],
    "impact_level": "medio",
    "timeframe": "2 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Velocidad",
    "master_decision_explanation": "Mantener experiencia ágil",
    "master_action": "Optimizar tiempos de respuesta",
    "master_action_explanation": "Evita lentitud futura",
    "master_tool": "Radar de Velocidad",
    "master_tool_explanation": "Monitoriza rapidez real"
  },

  "inputs": {
    "input_a": "Procesos Rápidos",
    "input_b": "Procesos Totales",
    "formula": "(Rápidos / Totales) x 100",
    "impact": "% Velocidad: Nivel de agilidad de la experiencia"
  },

  "review": {
    "input_revised_1": "Rápidos Post",
    "input_revised_2": "Totales Post",
    "result_revised": "Velocidad Mejorada"
  }
},
{
  "id": "TER-S9",
  "name": "Experiencia Poco Emocional",
  "specialty": "experiencia",
  "plan": "PRE",
  "domain": "emocional",
  "description": "La experiencia no genera conexión emocional, sorpresa ni recuerdo positivo en el cliente.",

  "kpi": {
    "question": "¿Tu experiencia emociona o solo cumple?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Activación emocional",
    "decision_explanation": "Crear momentos memorables",
    "action": "Diseñar micro‑momentos WOW",
    "action_explanation": "Aumenta conexión emocional",
    "tool": "Guía de Momentos WOW",
    "tool_explanation": "Define gestos emocionales clave",

    "objective": "Aumentar conexión emocional",
    "kpi_target": "Conexión > 75%",
    "activation_condition": "Conexión < 55%",
    "success_condition": "Experiencia memorable y emocional",
    "risk_if_ignored": "Clientes indiferentes y baja recomendación",
    "sequence": [
      "Identificar puntos fríos",
      "Diseñar micro‑momentos WOW",
      "Aplicar gestos emocionales"
    ],
    "impact_level": "medio",
    "timeframe": "3 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno Emocional",
    "master_decision_explanation": "Mantener conexión emocional",
    "master_action": "Optimizar momentos WOW",
    "master_action_explanation": "Evita experiencias frías",
    "master_tool": "Radar Emocional",
    "master_tool_explanation": "Monitoriza conexión emocional"
  },

  "inputs": {
    "input_a": "Momentos WOW",
    "input_b": "Momentos Totales",
    "formula": "(WOW / Totales) x 100",
    "impact": "% Emoción: Nivel de conexión emocional"
  },

  "review": {
    "input_revised_1": "WOW Post",
    "input_revised_2": "Totales Post",
    "result_revised": "Conexión Emocional Mejorada"
  }
},
{
  "id": "TER-S10",
  "name": "Experiencia de Alto Impacto",
  "specialty": "experiencia",
  "plan": "PRE",
  "domain": "excelencia",
  "description": "Nivel 10: experiencia rápida, clara, emocional, coherente y con una percepción de valor excepcional en todos los puntos de contacto.",

  "kpi": {
    "question": "¿Tu experiencia deja huella real en el cliente?",
    "scale_min": 1,
    "scale_max": 4
  },

  "thresholds": {
    "critical": 70,
    "recommended": 85,
    "optimizer": 95,
    "elite": 100
  },

  "treatment": {
    "decision": "Certificación de experiencia",
    "decision_explanation": "Validar excelencia en todos los puntos",
    "action": "Auditoría completa de experiencia, valor y emoción",
    "action_explanation": "Garantiza excelencia total",
    "tool": "Certificado S10 Experiencia",
    "tool_explanation": "Evalúa impacto, emoción y coherencia",

    "objective": "Aumentar excelencia de experiencia",
    "kpi_target": "Índice S10 > 90%",
    "activation_condition": "Índice < 80%",
    "success_condition": "Experiencia icónica y memorable",
    "risk_if_ignored": "Experiencia promedio y poco diferenciada",
    "sequence": [
      "Auditar experiencia completa",
      "Corregir desviaciones",
      "Certificar S10"
    ],
    "impact_level": "alto",
    "timeframe": "4 semanas"
  },

  "master_treatment": {
    "master_decision": "Gobierno de Excelencia de Experiencia",
    "master_decision_explanation": "Mantener experiencia icónica",
    "master_action": "Optimizar impacto emocional y funcional",
    "master_action_explanation": "Evita pérdida de excelencia",
    "master_tool": "Radar S10 Experiencia",
    "master_tool_explanation": "Monitoriza excelencia real"
  },

  "inputs": {
    "input_a": "Pilares de Experiencia",
    "input_b": "Pilares Cumplidos",
    "formula": "(Cumplidos / Pilares) x 100",
    "impact": "Índice S10 Experiencia: Nivel de excelencia emocional y funcional"
  },

  "review": {
    "input_revised_1": "Pilares Post",
    "input_revised_2": "Cumplidos Post",
    "result_revised": "Excelencia de Experiencia Alcanzada"
  }
}
  ]
},
{
  "specialty": "excelencia",
  "symptoms": [
    {
      "id": "OPE-S1",
      "name": "Procesos Manuales Críticos",
      "specialty": "excelencia",
      "plan": "PIE",
      "domain": "automatización",
      "description": "Procesos esenciales dependen de trabajo manual, generando errores, lentitud y dependencia del equipo.",
      "kpi": {
        "question": "¿Tu operativa funciona sola o solo funciona si alguien la empuja?",
        "scale_min": 1,
        "scale_max": 4
      },
      "thresholds": {
        "critical": 70,
        "recommended": 85,
        "optimizer": 95,
        "elite": 100
      },
      "treatment": {
        "decision": "Automatización urgente",
        "decision_explanation": "Eliminar tareas manuales críticas",
        "action": "Automatizar procesos repetitivos",
        "action_explanation": "Reduce errores y libera tiempo",
        "tool": "Mapa de Automatización",
        "tool_explanation": "Identifica tareas automatizables",
        "objective": "Aumentar eficiencia operativa",
        "kpi_target": "Automatización > 70%",
        "activation_condition": "Automatización < 50%",
        "success_condition": "Procesos automáticos y estables",
        "risk_if_ignored": "Errores, lentitud y dependencia humana",
        "sequence": [
          "Identificar procesos manuales",
          "Priorizar automatizables",
          "Implementar automatización"
        ],
        "impact_level": "alto",
        "timeframe": "1-2 semanas"
      },
      "master_treatment": {
        "master_decision": "Gobierno de Automatización",
        "master_decision_explanation": "Mantener procesos automáticos",
        "master_action": "Optimizar automatizaciones trimestralmente",
        "master_action_explanation": "Evita recaídas manuales",
        "master_tool": "Radar de Automatización",
        "master_tool_explanation": "Monitoriza nivel de automatización"
      },
      "inputs": {
        "input_a": "Procesos Automatizados",
        "input_b": "Procesos Totales",
        "formula": "(Automatizados / Totales) x 100",
        "impact": "% Automatización: Nivel de eficiencia operativa"
      },
      "review": {
        "input_revised_1": "Automatizados Post",
        "input_revised_2": "Totales Post",
        "result_revised": "Automatización Mejorada"
      }
    },
    {
      "id": "OPE-S2",
      "name": "Errores Recurrentes",
      "specialty": "excelencia",
      "plan": "PIE",
      "domain": "calidad",
      "description": "Los mismos errores se repiten en la operativa, afectando calidad, tiempos y satisfacción del cliente.",
      "kpi": {
        "question": "¿Tu empresa aprende o repite los mismos fallos una y otra vez?",
        "scale_min": 1,
        "scale_max": 4
      },
      "thresholds": {
        "critical": 70,
        "recommended": 85,
        "optimizer": 95,
        "elite": 100
      },
      "treatment": {
        "decision": "Corrección estructural",
        "decision_explanation": "Eliminar la causa raíz de los errores",
        "action": "Implementar protocolo de calidad",
        "action_explanation": "Reduce fallos y aumenta precisión",
        "tool": "Checklist de Calidad",
        "tool_explanation": "Estandariza pasos críticos",
        "objective": "Aumentar calidad operativa",
        "kpi_target": "Errores < 10%",
        "activation_condition": "Errores > 20%",
        "success_condition": "Operativa precisa y estable",
        "risk_if_ignored": "Costes ocultos y pérdida de confianza",
        "sequence": [
          "Identificar errores recurrentes",
          "Detectar causa raíz",
          "Aplicar protocolo de calidad"
        ],
        "impact_level": "alto",
        "timeframe": "1 semana"
      },
      "master_treatment": {
        "master_decision": "Gobierno de Calidad",
        "master_decision_explanation": "Mantener precisión operativa",
        "master_action": "Optimizar controles de calidad",
        "master_action_explanation": "Evita recaídas",
        "master_tool": "Radar de Calidad",
        "master_tool_explanation": "Monitoriza precisión real"
      },
      "inputs": {
        "input_a": "Errores Repetidos",
        "input_b": "Errores Totales",
        "formula": "(Repetidos / Totales) x 100",
        "impact": "% Repetición: Nivel de aprendizaje operativo"
      },
      "review": {
        "input_revised_1": "Repetidos Post",
        "input_revised_2": "Totales Post",
        "result_revised": "Errores Reducidos"
      }
    },
    {
      "id": "OPE-S3",
      "name": "Falta de Continuidad Operativa",
      "specialty": "excelencia",
      "plan": "PIE",
      "domain": "continuidad",
      "description": "La operativa depende de personas clave: si alguien falta, el sistema se detiene o pierde calidad.",
      "kpi": {
        "question": "Si mañana falta alguien clave, ¿la empresa sigue funcionando igual de bien?",
        "scale_min": 1,
        "scale_max": 4
      },
      "thresholds": {
        "critical": 70,
        "recommended": 85,
        "optimizer": 95,
        "elite": 100
      },
      "treatment": {
        "decision": "Sistematización urgente",
        "decision_explanation": "Convertir conocimiento en procesos",
        "action": "Documentar procesos críticos",
        "action_explanation": "Aumenta continuidad y estabilidad",
        "tool": "Manual Operativo Vivo",
        "tool_explanation": "Define procesos paso a paso",
        "objective": "Aumentar continuidad operativa",
        "kpi_target": "Continuidad > 75%",
        "activation_condition": "Continuidad < 55%",
        "success_condition": "Operativa estable sin depender de personas",
        "risk_if_ignored": "Parálisis operativa y errores críticos",
        "sequence": [
          "Identificar procesos críticos",
          "Documentar paso a paso",
          "Validar continuidad sin personas clave"
        ],
        "impact_level": "alto",
        "timeframe": "2 semanas"
      },
      "master_treatment": {
        "master_decision": "Gobierno de Continuidad",
        "master_decision_explanation": "Mantener operativa estable",
        "master_action": "Optimizar documentación operativa",
        "master_action_explanation": "Evita dependencia futura",
        "master_tool": "Radar de Continuidad",
        "master_tool_explanation": "Monitoriza estabilidad operativa"
      },
      "inputs": {
        "input_a": "Procesos Documentados",
        "input_b": "Procesos Críticos",
        "formula": "(Documentados / Críticos) x 100",
        "impact": "% Continuidad: Nivel de independencia operativa"
      },
      "review": {
        "input_revised_1": "Documentados Post",
        "input_revised_2": "Críticos Post",
        "result_revised": "Continuidad Mejorada"
      }
    },
    {
      "id": "OPE-S4",
      "name": "Cuellos de Botella Operativos",
      "specialty": "excelencia",
      "plan": "PRE",
      "domain": "flujo",
      "description": "Existen puntos donde el flujo se detiene o ralentiza, afectando tiempos, entregas y productividad.",
      "kpi": {
        "question": "¿Tu operativa fluye o se atasca en los mismos puntos?",
        "scale_min": 1,
        "scale_max": 4
      },
      "thresholds": {
        "critical": 70,
        "recommended": 85,
        "optimizer": 95,
        "elite": 100
      },
      "treatment": {
        "decision": "Desbloqueo de flujo",
        "decision_explanation": "Eliminar puntos de atasco",
        "action": "Rediseñar flujos críticos",
        "action_explanation": "Aumenta velocidad y eficiencia",
        "tool": "Mapa de Flujo Operativo",
        "tool_explanation": "Identifica cuellos de botella",
        "objective": "Aumentar fluidez operativa",
        "kpi_target": "Flujo > 75%",
        "activation_condition": "Flujo < 55%",
        "success_condition": "Operativa fluida y sin bloqueos",
        "risk_if_ignored": "Retrasos, estrés y baja productividad",
        "sequence": [
          "Detectar cuellos de botella",
          "Rediseñar flujos",
          "Validar fluidez"
        ],
        "impact_level": "medio",
        "timeframe": "2 semanas"
      },
      "master_treatment": {
        "master_decision": "Gobierno de Flujo",
        "master_decision_explanation": "Mantener operativa fluida",
        "master_action": "Optimizar flujos trimestralmente",
        "master_action_explanation": "Evita nuevos bloqueos",
        "master_tool": "Radar de Flujo",
        "master_tool_explanation": "Monitoriza fluidez operativa"
      },
      "inputs": {
        "input_a": "Puntos Fluidos",
        "input_b": "Puntos Totales",
        "formula": "(Fluidos / Totales) x 100",
        "impact": "% Fluidez: Nivel de flujo operativo"
      },
      "review": {
        "input_revised_1": "Fluidos Post",
        "input_revised_2": "Totales Post",
        "result_revised": "Flujo Mejorado"
      }
    },
    {
      "id": "OPE-S5",
      "name": "Dependencia del Dueño",
      "specialty": "excelencia",
      "plan": "PRE",
      "domain": "autonomía",
      "description": "La empresa depende del dueño para decisiones, validaciones o tareas operativas, limitando la escalabilidad.",
      "kpi": {
        "question": "¿Tu empresa funciona sin ti o solo contigo dentro?",
        "scale_min": 1,
        "scale_max": 4
      },
      "thresholds": {
        "critical": 70,
        "recommended": 85,
        "optimizer": 95,
        "elite": 100
      },
      "treatment": {
        "decision": "Delegación estructural",
        "decision_explanation": "Crear autonomía operativa",
        "action": "Definir sistema de delegación y autoridad",
        "action_explanation": "Aumenta independencia del dueño",
        "tool": "Matriz de Delegación",
        "tool_explanation": "Define qué decide quién",
        "objective": "Aumentar autonomía operativa",
        "kpi_target": "Autonomía > 70%",
        "activation_condition": "Autonomía < 50%",
        "success_condition": "Empresa que funciona sin el dueño",
        "risk_if_ignored": "Estancamiento y agotamiento del dueño",
        "sequence": [
          "Identificar tareas del dueño",
          "Delegar por niveles de autoridad",
          "Validar autonomía operativa"
        ],
        "impact_level": "alto",
        "timeframe": "3 semanas"
      },
      "master_treatment": {
        "master_decision": "Gobierno de Autonomía",
        "master_decision_explanation": "Mantener empresa independiente",
        "master_action": "Optimizar delegación y autoridad",
        "master_action_explanation": "Evita dependencia futura",
        "master_tool": "Radar de Autonomía",
        "master_tool_explanation": "Monitoriza independencia operativa"
      },
      "inputs": {
        "input_a": "Tareas Delegadas",
        "input_b": "Tareas Totales del Dueño",
        "formula": "(Delegadas / Totales) x 100",
        "impact": "% Delegación: Nivel de autonomía real"
      },
      "review": {
        "input_revised_1": "Delegadas Post",
        "input_revised_2": "Totales Post",
        "result_revised": "Autonomía Aumentada"
      }
    },
    {
      "id": "OPE-S6",
      "name": "Falta de Métricas Operativas",
      "specialty": "excelencia",
      "plan": "PRE",
      "domain": "medición",
      "description": "La operativa funciona sin métricas claras, dificultando la toma de decisiones y la mejora continua.",
      "kpi": {
        "question": "¿Tu operativa se gestiona con datos o con intuición?",
        "scale_min": 1,
        "scale_max": 4
      },
      "thresholds": {
        "critical": 70,
        "recommended": 85,
        "optimizer": 95,
        "elite": 100
      },
      "treatment": {
        "decision": "Instalación de métricas",
        "decision_explanation": "Medir lo que importa para mejorar",
        "action": "Definir KPIs operativos esenciales",
        "action_explanation": "Aumenta control y precisión",
        "tool": "Cuadro de Mando Operativo",
        "tool_explanation": "Centraliza métricas clave",
        "objective": "Aumentar control operativo",
        "kpi_target": "KPIs instalados > 80%",
        "activation_condition": "KPIs instalados < 60%",
        "success_condition": "Operativa medida y optimizable",
        "risk_if_ignored": "Ceguera operativa y decisiones erróneas",
        "sequence": [
          "Identificar métricas críticas",
          "Definir KPIs esenciales",
          "Instalar cuadro de mando"
        ],
        "impact_level": "alto",
        "timeframe": "2 semanas"
      },
      "master_treatment": {
        "master_decision": "Gobierno de Métricas",
        "master_decision_explanation": "Mantener medición continua",
        "master_action": "Optimizar KPIs trimestralmente",
        "master_action_explanation": "Evita métricas obsoletas",
        "master_tool": "Radar de KPIs",
        "master_tool_explanation": "Monitoriza salud operativa"
      },
      "inputs": {
        "input_a": "KPIs Instalados",
        "input_b": "KPIs Necesarios",
        "formula": "(Instalados / Necesarios) x 100",
        "impact": "% Métricas: Nivel de medición operativa"
      },
      "review": {
        "input_revised_1": "Instalados Post",
        "input_revised_2": "Necesarios Post",
        "result_revised": "Métricas Instaladas"
      }
    },
    {
      "id": "OPE-S7",
      "name": "Falta de Control de Calidad en Tiempo Real",
      "specialty": "excelencia",
      "plan": "PRE",
      "domain": "calidad",
      "description": "La calidad se revisa tarde, cuando el error ya ha ocurrido, generando retrabajo y costes ocultos.",
      "kpi": {
        "question": "¿Detectas errores antes o después de que afecten al cliente?",
        "scale_min": 1,
        "scale_max": 4
      },
      "thresholds": {
        "critical": 70,
        "recommended": 85,
        "optimizer": 95,
        "elite": 100
      },
      "treatment": {
        "decision": "Control en tiempo real",
        "decision_explanation": "Detectar errores antes de que escalen",
        "action": "Instalar puntos de control automáticos",
        "action_explanation": "Aumenta precisión y reduce retrabajo",
        "tool": "Sistema de Control en Tiempo Real",
        "tool_explanation": "Detecta fallos al instante",
        "objective": "Aumentar precisión operativa",
        "kpi_target": "Control > 75%",
        "activation_condition": "Control < 55%",
        "success_condition": "Errores detectados antes de impactar",
        "risk_if_ignored": "Retrabajo, costes y mala experiencia",
        "sequence": [
          "Identificar puntos críticos",
          "Instalar controles automáticos",
          "Validar detección temprana"
        ],
        "impact_level": "alto",
        "timeframe": "2 semanas"
      },
      "master_treatment": {
        "master_decision": "Gobierno de Calidad en Tiempo Real",
        "master_decision_explanation": "Mantener precisión continua",
        "master_action": "Optimizar puntos de control",
        "master_action_explanation": "Evita errores tardíos",
        "master_tool": "Radar de Control",
        "master_tool_explanation": "Monitoriza detección temprana"
      },
      "inputs": {
        "input_a": "Errores Detectados a Tiempo",
        "input_b": "Errores Totales",
        "formula": "(ATiempo / Totales) x 100",
        "impact": "% Detección Temprana: Nivel de control real"
      },
      "review": {
        "input_revised_1": "ATiempo Post",
        "input_revised_2": "Totales Post",
        "result_revised": "Control Mejorado"
      }
    },
    {
      "id": "OPE-S8",
      "name": "Falta de Redundancia Operativa",
      "specialty": "excelencia",
      "plan": "PRE",
      "domain": "redundancia",
      "description": "No existen sistemas alternativos o backups que garanticen continuidad ante fallos o imprevistos.",
      "kpi": {
        "question": "Si algo falla, ¿tu empresa sigue o se detiene?",
        "scale_min": 1,
        "scale_max": 4
      },
      "thresholds": {
        "critical": 70,
        "recommended": 85,
        "optimizer": 95,
        "elite": 100
      },
      "treatment": {
        "decision": "Creación de redundancias",
        "decision_explanation": "Asegurar continuidad ante fallos",
        "action": "Diseñar sistemas alternativos y backups",
        "action_explanation": "Aumenta resiliencia operativa",
        "tool": "Plan de Redundancia Operativa",
        "tool_explanation": "Define backups y rutas alternativas",
        "objective": "Aumentar resiliencia operativa",
        "kpi_target": "Redundancia > 70%",
        "activation_condition": "Redundancia < 50%",
        "success_condition": "Operativa estable ante fallos",
        "risk_if_ignored": "Parálisis operativa y pérdidas",
        "sequence": [
          "Identificar puntos vulnerables",
          "Diseñar redundancias",
          "Testear continuidad"
        ],
        "impact_level": "alto",
        "timeframe": "3 semanas"
      },
      "master_treatment": {
        "master_decision": "Gobierno de Redundancia",
        "master_decision_explanation": "Mantener continuidad garantizada",
        "master_action": "Optimizar backups y rutas",
        "master_action_explanation": "Evita vulnerabilidades futuras",
        "master_tool": "Radar de Redundancia",
        "master_tool_explanation": "Monitoriza resiliencia operativa"
      },
      "inputs": {
        "input_a": "Backups Activos",
        "input_b": "Backups Necesarios",
        "formula": "(Activos / Necesarios) x 100",
        "impact": "% Redundancia: Nivel de resiliencia operativa"
      },
      "review": {
        "input_revised_1": "Activos Post",
        "input_revised_2": "Necesarios Post",
        "result_revised": "Redundancia Aumentada"
      }
    },
    {
      "id": "OPE-S9",
      "name": "Falta de Integración entre Sistemas",
      "specialty": "excelencia",
      "plan": "PRE",
      "domain": "integración",
      "description": "Las herramientas no se comunican entre sí, generando duplicidad, errores y pérdida de tiempo.",
      "kpi": {
        "question": "¿Tus sistemas trabajan juntos o cada uno va por su cuenta?",
        "scale_min": 1,
        "scale_max": 4
      },
      "thresholds": {
        "critical": 70,
        "recommended": 85,
        "optimizer": 95,
        "elite": 100
      },
      "treatment": {
        "decision": "Integración sistémica",
        "decision_explanation": "Conectar herramientas para crear flujo",
        "action": "Integrar sistemas clave",
        "action_explanation": "Aumenta eficiencia y reduce errores",
        "tool": "Mapa de Integración",
        "tool_explanation": "Define conexiones entre sistemas",
        "objective": "Aumentar eficiencia sistémica",
        "kpi_target": "Integración > 75%",
        "activation_condition": "Integración < 55%",
        "success_condition": "Sistemas conectados y sin duplicidades",
        "risk_if_ignored": "Errores, lentitud y caos operativo",
        "sequence": [
          "Auditar sistemas actuales",
          "Definir integraciones necesarias",
          "Implementar conexiones"
        ],
        "impact_level": "medio",
        "timeframe": "3 semanas"
      },
      "master_treatment": {
        "master_decision": "Gobierno de Integración",
        "master_decision_explanation": "Mantener sistemas conectados",
        "master_action": "Optimizar integraciones",
        "master_action_explanation": "Evita desconexiones futuras",
        "master_tool": "Radar de Integración",
        "master_tool_explanation": "Monitoriza conexión sistémica"
      },
      "inputs": {
        "input_a": "Integraciones Activas",
        "input_b": "Integraciones Necesarias",
        "formula": "(Activas / Necesarias) x 100",
        "impact": "% Integración: Nivel de conexión entre sistemas"
      },
      "review": {
        "input_revised_1": "Activas Post",
        "input_revised_2": "Necesarias Post",
        "result_revised": "Integración Mejorada"
      }
    },
    {
      "id": "OPE-S10",
      "name": "Excelencia Operativa",
      "specialty": "excelencia",
      "plan": "PRE",
      "domain": "excelencia",
      "description": "Nivel 10: operativa autónoma, rápida, precisa, integrada, sin errores y capaz de funcionar perfectamente sin el dueño.",
      "kpi": {
        "question": "¿Tu empresa funciona como un sistema inteligente y autónomo?",
        "scale_min": 1,
        "scale_max": 4
      },
      "thresholds": {
        "critical": 70,
        "recommended": 85,
        "optimizer": 95,
        "elite": 100
      },
      "treatment": {
        "decision": "Certificación de excelencia operativa",
        "decision_explanation": "Validar autonomía, precisión y continuidad",
        "action": "Auditoría completa de automatización, calidad y flujo",
        "action_explanation": "Garantiza excelencia total",
        "tool": "Certificado S10 Operativo",
        "tool_explanation": "Evalúa autonomía y precisión",
        "objective": "Aumentar excelencia operativa",
        "kpi_target": "Índice S10 > 90%",
        "activation_condition": "Índice < 80%",
        "success_condition": "Operativa autónoma, robusta y escalable",
        "risk_if_ignored": "Dependencia, errores y fragilidad operativa",
        "sequence": [
          "Auditar operativa completa",
          "Corregir desviaciones",
          "Certificar S10"
        ],
        "impact_level": "alto",
        "timeframe": "4 semanas"
      },
      "master_treatment": {
        "master_decision": "Gobierno de Excelencia Operativa",
        "master_decision_explanation": "Mantener operativa de clase mundial",
        "master_action": "Optimizar automatización, calidad y flujo",
        "master_action_explanation": "Evita deterioro operativo",
        "master_tool": "Radar S10 Operativo",
        "master_tool_explanation": "Monitoriza excelencia real"
      },
      "inputs": {
        "input_a": "Pilares Operativos",
        "input_b": "Pilares Cumplidos",
        "formula": "(Cumplidos / Pilares) x 100",
        "impact": "Índice S10 Operativo: Nivel de excelencia operativa"
      },
      "review": {
        "input_revised_1": "Pilares Post",
        "input_revised_2": "Cumplidos Post",
        "result_revised": "Excelencia Operativa Alcanzada" 
        }
      }
    ]
  }
]


@router.post("/seed")
async def seed_symptom_master():
    for s in FINANZAS_SYMPTOMS:
        existing = await db.symptom_master.find_one({
            "department": s["department"],
            "code": s["code"],
        })
        if not existing:
            await db.symptom_master.insert_one(s)
    return {"ok": True}

@router.get("/", response_model=List[SymptomMaster])
async def list_all_symptoms():
    cursor = db.symptom_master.find({})
    docs = await cursor.to_list(length=1000)
    return [SymptomMaster(**d) for d in docs]

@router.get("/by-department/{department}", response_model=List[SymptomMaster])
async def list_by_department(department: str):
    cursor = db.symptom_master.find({"department": department.upper()})
    docs = await cursor.to_list(length=1000)
    return [SymptomMaster(**d) for d in docs]